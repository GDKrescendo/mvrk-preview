<?php
/**
 * Generic fallback template (blog/archive).
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="section-pad">
	<div class="container-mvrk legal__inner">
		<?php if ( have_posts() ) : ?>
			<header class="sec-head">
				<p class="eyebrow"><?php esc_html_e( 'MVRK', 'mvrk' ); ?></p>
				<h1 class="legal__title"><?php echo esc_html( get_the_archive_title() ? wp_strip_all_tags( get_the_archive_title() ) : __( 'Latest', 'mvrk' ) ); ?></h1>
			</header>
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article <?php post_class( 'mvrk-post' ); ?>>
					<h2 class="legal__title" style="font-size:var(--text-h3)"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<div><?php the_excerpt(); ?></div>
				</article>
			<?php endwhile; ?>
			<div class="mvrk-pagination"><?php posts_nav_link(); ?></div>
		<?php else : ?>
			<h1 class="legal__title"><?php esc_html_e( 'Nothing here yet', 'mvrk' ); ?></h1>
			<p><?php esc_html_e( 'Check back soon.', 'mvrk' ); ?></p>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
