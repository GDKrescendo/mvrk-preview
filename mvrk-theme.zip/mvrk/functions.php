<?php
/**
 * MVRK theme functions.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MVRK_VERSION', '1.0.4' );
define( 'MVRK_DIR', get_template_directory() );
define( 'MVRK_URI', get_template_directory_uri() );

require_once MVRK_DIR . '/inc/config.php';
require_once MVRK_DIR . '/inc/template-helpers.php';
require_once MVRK_DIR . '/inc/setup-pages.php';
require_once MVRK_DIR . '/inc/contact-form.php';
require_once MVRK_DIR . '/inc/seo.php';
if ( class_exists( 'WooCommerce' ) ) {
	require_once MVRK_DIR . '/inc/woocommerce.php';
}

/**
 * Theme setup.
 */
function mvrk_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'custom-logo', array(
		'height'      => 44,
		'width'       => 160,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );

	// WooCommerce.
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'mvrk' ),
		'footer'  => __( 'Footer Menu', 'mvrk' ),
	) );
}
add_action( 'after_setup_theme', 'mvrk_setup' );

/**
 * Enqueue styles and scripts.
 */
function mvrk_assets() {
	// Google Fonts — Bricolage Grotesque (display) + Hanken Grotesk (body). Both off the banned list.
	wp_enqueue_style(
		'mvrk-fonts',
		'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&family=Hanken+Grotesk:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	wp_enqueue_style( 'mvrk-app', MVRK_URI . '/assets/css/app.css', array(), MVRK_VERSION );

	// Page-contextual styles.
	if ( is_front_page() ) {
		wp_enqueue_style( 'mvrk-home', MVRK_URI . '/assets/css/home.css', array( 'mvrk-app' ), MVRK_VERSION );
	}
	if ( function_exists( 'is_woocommerce' ) && ( is_woocommerce() || is_cart() || is_checkout() ) ) {
		wp_enqueue_style( 'mvrk-shop', MVRK_URI . '/assets/css/shop.css', array( 'mvrk-app' ), MVRK_VERSION );
	}

	// GSAP + ScrollTrigger (CDN, deferred). Native scrolling — no smooth-scroll hijack (perf).
	wp_enqueue_script( 'gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/gsap.min.js', array(), '3.13.0', true );
	wp_enqueue_script( 'gsap-st', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.13.0/ScrollTrigger.min.js', array( 'gsap' ), '3.13.0', true );

	wp_enqueue_script( 'mvrk-main', MVRK_URI . '/assets/js/main.js', array( 'gsap', 'gsap-st' ), MVRK_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'mvrk_assets' );

/**
 * Add the `js` class as early as possible (no-JS reveal fallback).
 */
function mvrk_js_flag() {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
}
add_action( 'wp_head', 'mvrk_js_flag', 1 );

/**
 * Output the 21+ age gate + theme-color in the head/footer.
 */
function mvrk_head_meta() {
	echo '<meta name="theme-color" content="#1c1411">' . "\n";
}
add_action( 'wp_head', 'mvrk_head_meta' );

/**
 * Render the age gate at the top of <body>.
 */
function mvrk_age_gate() {
	get_template_part( 'template-parts/age-gate' );
}
add_action( 'wp_body_open', 'mvrk_age_gate' );

/**
 * WooCommerce: declare support and tune layout.
 * Remove default WooCommerce wrappers; we provide our own in templates.
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
add_action( 'woocommerce_before_main_content', 'mvrk_wc_wrapper_start', 10 );
add_action( 'woocommerce_after_main_content', 'mvrk_wc_wrapper_end', 10 );
function mvrk_wc_wrapper_start() {
	echo '<main id="main"><div class="container-mvrk wc-wrap">';
}
function mvrk_wc_wrapper_end() {
	echo '</div></main>';
}

// Products per row / page.
add_filter( 'loop_shop_columns', function () { return 4; } );
add_filter( 'loop_shop_per_page', function () { return 12; } );

/**
 * Disable WooCommerce default stylesheet bloat where we override (keep layout sheet).
 */
add_filter( 'woocommerce_enqueue_styles', function ( $styles ) {
	return $styles; // keep defaults; our shop.css layers on top.
} );
