<?php
/**
 * Page: Responsible Use.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$d   = mvrk_get( 'disclaimer' );
$biz = mvrk_get( 'business' );

$rules = array(
	array( 'target', 'Start low, go slow', 'Begin with a single 1/4-tablet serving and wait. Never chase an effect by stacking servings.' ),
	array( 'clock', 'Give it time', 'Effects aren\'t instant. Re-dosing too soon is how people get into trouble. Patience is control.' ),
	array( 'shield', 'Know your limit', 'Tolerance and body chemistry differ. What\'s right for someone else may not be right for you.' ),
	array( 'alert-triangle', 'Don\'t mix', 'Do not combine with alcohol, opioids, sedatives, or other substances. Don\'t drive or operate machinery.' ),
);
$avoid = array(
	'Anyone under 21',
	'People who are pregnant or nursing',
	'Anyone with a history of substance-use disorder, unless cleared by a clinician',
	'People taking opioids, sedatives, or other interacting medications',
	'Anyone with a heart, liver, or respiratory condition without a doctor\'s guidance',
);
?>
<main id="main">
	<section class="ru-hero">
		<div class="container-mvrk reveal">
			<p class="eyebrow"><?php esc_html_e( 'Read this first', 'mvrk' ); ?></p>
			<h1 class="ru-hero__title"><?php esc_html_e( 'Responsible use', 'mvrk' ); ?></h1>
			<p class="ru-hero__lead"><?php echo wp_kses_post( __( 'MVRK products contain 7-hydroxymitragynine, which acts on opioid receptors and <strong>can be habit-forming</strong>. Control starts with information. Here\'s what you need to know before you ever open a jar.', 'mvrk' ) ); ?></p>
			<div class="ru-hero__badge"><?php mvrk_icon( 'shield-check' ); ?> <?php esc_html_e( 'For adults 21+ only', 'mvrk' ); ?></div>
		</div>
	</section>

	<section class="section-pad">
		<div class="container-mvrk">
			<h2 class="ru-h2 reveal"><?php esc_html_e( 'How to use with control', 'mvrk' ); ?></h2>
			<div class="ru-rules reveal" data-stagger>
				<?php foreach ( $rules as $r ) : ?>
					<div class="ru-rule card">
						<span class="ru-rule__icon"><?php mvrk_icon( $r[0], 'ico-lg' ); ?></span>
						<div>
							<h3 class="ru-rule__title"><?php echo esc_html( $r[1] ); ?></h3>
							<p class="ru-rule__body"><?php echo esc_html( $r[2] ); ?></p>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<section class="section-pad ru-avoid-wrap">
		<div class="container-mvrk ru-cols">
			<div class="reveal">
				<h2 class="ru-h2"><?php esc_html_e( 'Who should not use MVRK', 'mvrk' ); ?></h2>
				<ul class="ru-avoid">
					<?php foreach ( $avoid as $a ) : ?>
						<li><?php mvrk_icon( 'x' ); ?> <?php echo esc_html( $a ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<div class="ru-help card reveal">
				<h3 class="ru-help__title"><?php esc_html_e( 'Struggling? Reach out.', 'mvrk' ); ?></h3>
				<p class="ru-help__body"><?php esc_html_e( 'Dependence is real, and asking for help is strength, not weakness. The SAMHSA National Helpline is free, confidential, and available 24/7.', 'mvrk' ); ?></p>
				<a href="tel:18006624357" class="btn btn-primary ru-help__btn"><?php mvrk_icon( 'phone' ); ?> 1-800-662-4357</a>
				<p class="ru-help__note"><?php esc_html_e( 'Treatment referral & information · English and Spanish', 'mvrk' ); ?></p>
			</div>
		</div>
	</section>

	<section class="section-pad">
		<div class="container-mvrk ru-legal reveal">
			<h2 class="ru-h2"><?php esc_html_e( 'The fine print that actually matters', 'mvrk' ); ?></h2>
			<p><?php echo esc_html( $d['fda'] ); ?></p>
			<p><?php echo esc_html( $d['dependence'] ); ?></p>
			<p><?php echo esc_html( $d['shipping'] ); ?></p>
			<p class="ru-legal__contact"><?php esc_html_e( 'Questions about a product or its lab testing?', 'mvrk' ); ?> <a href="mailto:<?php echo esc_attr( $biz['email'] ); ?>"><?php echo esc_html( $biz['email'] ); ?></a></p>
		</div>
	</section>
</main>

<style>
	.ru-hero { padding-block: clamp(2.5rem, 6vw, 4.5rem) 0; }
	.ru-hero__title { font-size: var(--text-display); font-weight: 800; margin: 0.5rem 0 1.25rem; }
	.ru-hero__lead { color: var(--color-muted); font-size: var(--text-lead); max-width: 42rem; }
	.ru-hero__lead strong { color: var(--color-ink); }
	.ru-hero__badge { display: inline-flex; align-items: center; gap: 0.5rem; margin-top: 1.75rem; padding: 0.55rem 1rem; border: 1px solid var(--color-accent); border-radius: 99px; color: var(--color-accent); font-weight: 600; font-size: 0.9rem; }
	.ru-h2 { font-size: var(--text-h2); margin-bottom: 1.75rem; }
	.ru-rules { display: grid; gap: 1.25rem; grid-template-columns: 1fr; }
	.ru-rule { display: flex; gap: 1.1rem; padding: 1.6rem; }
	.ru-rule__icon { flex: none; display: inline-grid; place-items: center; width: 3rem; height: 3rem; border-radius: 0.75rem; background: var(--color-accent-soft); color: var(--color-accent); }
	.ru-rule__title { font-size: 1.15rem; margin-bottom: 0.4rem; }
	.ru-rule__body { color: var(--color-muted); font-size: 0.92rem; }
	@media (min-width: 768px) { .ru-rules { grid-template-columns: repeat(2, 1fr); } }
	.ru-avoid-wrap { background: var(--color-base); }
	.ru-cols { display: grid; gap: 2.5rem; grid-template-columns: 1fr; align-items: start; }
	.ru-avoid { display: grid; gap: 0.9rem; list-style: none; padding: 0; }
	.ru-avoid li { display: flex; align-items: center; gap: 0.7rem; color: var(--color-ink); }
	.ru-avoid svg { color: var(--color-accent); flex: none; }
	.ru-help { padding: 2rem; }
	.ru-help__title { font-size: 1.4rem; margin-bottom: 0.75rem; }
	.ru-help__body { color: var(--color-muted); margin-bottom: 1.5rem; }
	.ru-help__btn { width: 100%; }
	.ru-help__note { margin-top: 0.85rem; font-size: 0.8rem; color: var(--color-faint); text-align: center; }
	@media (min-width: 900px) { .ru-cols { grid-template-columns: 1.3fr 0.7fr; gap: 3rem; } }
	.ru-legal { max-width: 48rem; }
	.ru-legal p { color: var(--color-muted); font-size: 0.9rem; line-height: 1.65; margin-bottom: 1rem; }
	.ru-legal__contact a { color: var(--color-accent); font-weight: 600; }
</style>
<?php
get_footer();
