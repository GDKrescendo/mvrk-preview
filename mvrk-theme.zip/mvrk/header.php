<?php
/**
 * Header.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvrk_nav = array(
	array( 'Shop', function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' ) ),
	array( 'Win Free MVRK', home_url( '/giveaway/' ) ),
	array( 'Winners', home_url( '/winners/' ) ),
	array( 'Our Story', home_url( '/story/' ) ),
	array( 'Responsible Use', home_url( '/responsible-use/' ) ),
	array( 'Contact', home_url( '/contact/' ) ),
);
$mvrk_logo = MVRK_URI . '/assets/img/mvrk-logo.png';
$mvrk_shop = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a href="#main" class="skip-link"><?php esc_html_e( 'Skip to main content', 'mvrk' ); ?></a>

<header id="site-header" class="header">
	<div class="container-mvrk header__inner">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="header__logo" aria-label="<?php esc_attr_e( 'MVRK home', 'mvrk' ); ?>">
			<img src="<?php echo esc_url( $mvrk_logo ); ?>" alt="MVRK" width="120" height="40" />
		</a>

		<nav class="header__nav" aria-label="<?php esc_attr_e( 'Primary', 'mvrk' ); ?>">
			<?php foreach ( $mvrk_nav as $item ) :
				$active = ( untrailingslashit( $item[1] ) === untrailingslashit( home_url( $GLOBALS['wp']->request ?? '' ) ) );
				?>
				<a href="<?php echo esc_url( $item[1] ); ?>" class="header__link<?php echo $active ? ' is-active' : ''; ?>"<?php echo $active ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $item[0] ); ?></a>
			<?php endforeach; ?>
		</nav>

		<div class="header__cta">
			<a href="<?php echo esc_url( $mvrk_shop ); ?>" class="btn btn-primary header__shop"><?php esc_html_e( 'Shop the Lineup', 'mvrk' ); ?></a>
			<button type="button" id="nav-toggle" class="header__burger" aria-label="<?php esc_attr_e( 'Open menu', 'mvrk' ); ?>" aria-expanded="false" aria-controls="mobile-nav">
				<?php mvrk_icon( 'menu', 'ico-lg' ); ?>
			</button>
		</div>
	</div>
</header>

<div id="mobile-nav" class="mobile-nav" hidden>
	<div class="mobile-nav__head container-mvrk">
		<span class="eyebrow"><?php esc_html_e( 'Menu', 'mvrk' ); ?></span>
		<button type="button" id="nav-close" class="header__burger" aria-label="<?php esc_attr_e( 'Close menu', 'mvrk' ); ?>">
			<?php mvrk_icon( 'x', 'ico-lg' ); ?>
		</button>
	</div>
	<nav class="mobile-nav__links container-mvrk" aria-label="<?php esc_attr_e( 'Mobile', 'mvrk' ); ?>">
		<?php foreach ( $mvrk_nav as $item ) : ?>
			<a href="<?php echo esc_url( $item[1] ); ?>" class="mobile-nav__link"><?php echo esc_html( $item[0] ); ?></a>
		<?php endforeach; ?>
		<a href="<?php echo esc_url( $mvrk_shop ); ?>" class="btn btn-primary mobile-nav__shop"><?php esc_html_e( 'Shop the Lineup', 'mvrk' ); ?></a>
	</nav>
</div>
