<?php
/**
 * Page: Win Free MVRK (giveaway). Renders the [mvrk_giveaway] shortcode
 * full-width, without the default page title wrapper.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main">
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</main>
<?php
get_footer();
