<?php
/**
 * Page: Contact.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$biz  = mvrk_get( 'business' );
$sent = isset( $_GET['sent'] ) ? sanitize_key( $_GET['sent'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
?>
<main id="main">
	<section class="contact-hero">
		<div class="container-mvrk reveal">
			<p class="eyebrow"><?php esc_html_e( 'Let\'s connect', 'mvrk' ); ?></p>
			<h1 class="contact-hero__title"><?php esc_html_e( 'Get in touch', 'mvrk' ); ?></h1>
			<p class="contact-hero__lead"><?php esc_html_e( 'Product questions, lab-test (COA) requests, wholesale, or order help — send a message and we\'ll get back to you.', 'mvrk' ); ?></p>
		</div>
	</section>

	<section class="section-pad">
		<div class="container-mvrk contact-grid">
			<div class="contact-info reveal">
				<a href="mailto:<?php echo esc_attr( $biz['email'] ); ?>" class="contact-item card">
					<span class="contact-item__icon"><?php mvrk_icon( 'mail' ); ?></span>
					<span><span class="contact-item__label"><?php esc_html_e( 'Email', 'mvrk' ); ?></span><?php echo esc_html( $biz['email'] ); ?></span>
				</a>
				<?php if ( ! empty( $biz['phone'] ) ) : ?>
					<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $biz['phone'] ) ); ?>" class="contact-item card">
						<span class="contact-item__icon"><?php mvrk_icon( 'phone' ); ?></span>
						<span><span class="contact-item__label"><?php esc_html_e( 'Phone', 'mvrk' ); ?></span><?php echo esc_html( $biz['phone'] ); ?></span>
					</a>
				<?php endif; ?>
				<div class="contact-item card">
					<span class="contact-item__icon"><?php mvrk_icon( 'map-pin' ); ?></span>
					<span><span class="contact-item__label"><?php esc_html_e( 'Based in', 'mvrk' ); ?></span><?php echo esc_html( $biz['country'] ); ?></span>
				</div>
				<?php if ( ! empty( $biz['hours'] ) ) : ?>
					<div class="contact-item card">
						<span class="contact-item__icon"><?php mvrk_icon( 'clock' ); ?></span>
						<span><span class="contact-item__label"><?php esc_html_e( 'Hours', 'mvrk' ); ?></span><?php echo esc_html( $biz['hours'] ); ?></span>
					</div>
				<?php endif; ?>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>" class="contact-item card">
					<span class="contact-item__icon"><?php mvrk_icon( 'shield-check' ); ?></span>
					<span><span class="contact-item__label"><?php esc_html_e( 'Before you buy', 'mvrk' ); ?></span><?php esc_html_e( 'Read our responsible-use guide', 'mvrk' ); ?></span>
				</a>
			</div>

			<div class="contact-form card reveal">
				<?php if ( 'ok' === $sent ) : ?>
					<div class="contact-alert contact-alert--ok"><?php mvrk_icon( 'check-circle' ); ?> <span><?php esc_html_e( 'Thanks — your message is on its way. We\'ll be in touch soon.', 'mvrk' ); ?></span></div>
				<?php elseif ( 'error' === $sent ) : ?>
					<div class="contact-alert contact-alert--err"><span><?php esc_html_e( 'Please check your name, a valid email, and a short message, then try again.', 'mvrk' ); ?></span></div>
				<?php endif; ?>

				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" novalidate>
					<input type="hidden" name="action" value="mvrk_contact" />
					<?php wp_nonce_field( 'mvrk_contact', 'mvrk_contact_nonce' ); ?>
					<div class="field">
						<label for="c-name"><?php esc_html_e( 'Name', 'mvrk' ); ?></label>
						<input id="c-name" name="name" type="text" autocomplete="name" required />
					</div>
					<div class="field">
						<label for="c-email"><?php esc_html_e( 'Email', 'mvrk' ); ?></label>
						<input id="c-email" name="email" type="email" autocomplete="email" required />
					</div>
					<div class="field">
						<label for="c-phone"><?php esc_html_e( 'Phone', 'mvrk' ); ?> <span class="opt"><?php esc_html_e( '(optional)', 'mvrk' ); ?></span></label>
						<input id="c-phone" name="phone" type="tel" autocomplete="tel" />
					</div>
					<div class="field">
						<label for="c-message"><?php esc_html_e( 'Message', 'mvrk' ); ?></label>
						<textarea id="c-message" name="message" rows="5" required></textarea>
					</div>
					<div class="hp" aria-hidden="true">
						<label for="c-company"><?php esc_html_e( 'Company', 'mvrk' ); ?></label>
						<input id="c-company" name="company" type="text" tabindex="-1" autocomplete="off" />
					</div>
					<button type="submit" class="btn btn-primary contact-form__submit"><?php esc_html_e( 'Send Message', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right' ); ?></button>
					<p class="contact-form__note"><?php esc_html_e( 'By contacting us you confirm you are 21 or older.', 'mvrk' ); ?></p>
				</form>
			</div>
		</div>
	</section>
</main>

<style>
	.contact-hero { padding-block: clamp(2.5rem, 6vw, 4.5rem) 0; }
	.contact-hero__title { font-size: var(--text-display); font-weight: 800; margin: 0.5rem 0 1rem; }
	.contact-hero__lead { color: var(--color-muted); font-size: var(--text-lead); max-width: 36rem; }
	.contact-grid { display: grid; gap: 2rem; grid-template-columns: 1fr; align-items: start; }
	.contact-info { display: grid; gap: 1rem; }
	.contact-item { display: flex; align-items: center; gap: 1rem; padding: 1.25rem; color: var(--color-ink); }
	.contact-item__icon { display: inline-grid; place-items: center; width: 2.75rem; height: 2.75rem; flex: none; border-radius: 0.7rem; background: var(--color-accent-soft); color: var(--color-accent); }
	.contact-item__label { display: block; font-size: 0.72rem; letter-spacing: 0.1em; text-transform: uppercase; color: var(--color-faint); margin-bottom: 0.15rem; }
	.contact-form { padding: clamp(1.5rem, 4vw, 2.25rem); }
	.contact-form form { display: grid; gap: 1.1rem; }
	.field { display: grid; gap: 0.4rem; }
	.field label { font-size: 0.85rem; font-weight: 600; color: var(--color-ink); }
	.field .opt { color: var(--color-faint); font-weight: 400; }
	.field input, .field textarea { width: 100%; background: var(--color-base); border: 1px solid var(--color-line); border-radius: 0.6rem; padding: 0.8rem 0.9rem; color: var(--color-ink); font: inherit; transition: border-color 0.2s; }
	.field input:focus, .field textarea:focus { border-color: var(--color-accent); outline: none; }
	.field textarea { resize: vertical; }
	.hp { position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden; }
	.contact-form__submit { margin-top: 0.5rem; }
	.contact-form__note { font-size: 0.78rem; color: var(--color-faint); text-align: center; }
	.contact-alert { display: flex; gap: 0.6rem; align-items: center; padding: 0.9rem 1.1rem; border-radius: 0.7rem; margin-bottom: 1.25rem; font-size: 0.9rem; }
	.contact-alert--ok { background: oklch(0.30 0.08 150 / 0.25); border: 1px solid oklch(0.5 0.12 150 / 0.4); }
	.contact-alert--err { background: var(--color-accent-soft); border: 1px solid oklch(0.45 0.12 25 / 0.5); }
	@media (min-width: 900px) { .contact-grid { grid-template-columns: 0.85fr 1.15fr; gap: 2.5rem; } }
</style>
<?php
get_footer();
