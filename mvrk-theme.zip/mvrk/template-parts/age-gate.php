<?php
/**
 * 21+ age gate.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$d = mvrk_get( 'disclaimer' );
?>
<div id="age-gate" class="age-gate" role="dialog" aria-modal="true" aria-labelledby="age-gate-title" aria-describedby="age-gate-desc" hidden>
	<div class="age-gate__panel">
		<p class="eyebrow"><?php esc_html_e( 'MVRK · Verification', 'mvrk' ); ?></p>
		<h2 id="age-gate-title" class="age-gate__title"><?php esc_html_e( 'Are you 21 or older?', 'mvrk' ); ?></h2>
		<p id="age-gate-desc" class="age-gate__desc">
			<?php echo esc_html( $d['short'] ); ?> <?php esc_html_e( 'You must confirm you are of legal age to enter this site.', 'mvrk' ); ?>
		</p>
		<div class="age-gate__actions">
			<button type="button" id="age-yes" class="btn btn-primary"><?php esc_html_e( 'Yes, I am 21+', 'mvrk' ); ?></button>
			<button type="button" id="age-no" class="btn btn-secondary"><?php esc_html_e( 'No, exit', 'mvrk' ); ?></button>
		</div>
		<p class="age-gate__fine"><?php echo esc_html( $d['dependence'] ); ?></p>
	</div>
</div>

<style>
	.age-gate { position: fixed; inset: 0; z-index: 100; display: grid; place-items: center; padding: 1.5rem; background: oklch(0.1 0.01 35 / 0.86); backdrop-filter: blur(10px); }
	.age-gate[hidden] { display: none; }
	.age-gate__panel { width: 100%; max-width: 30rem; background: var(--color-surface); border: 1px solid var(--color-line); border-radius: 1.25rem; padding: clamp(1.75rem, 5vw, 2.75rem); box-shadow: var(--shadow-pop); text-align: center; }
	.age-gate__title { font-size: var(--text-h2); margin: 0.75rem 0 0.5rem; }
	.age-gate__desc { color: var(--color-muted); font-size: 0.98rem; margin-bottom: 1.5rem; }
	.age-gate__actions { display: flex; flex-wrap: wrap; gap: 0.75rem; justify-content: center; }
	.age-gate__actions .btn { flex: 1 1 12rem; }
	.age-gate__fine { margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--color-line); color: var(--color-faint); font-size: 0.72rem; line-height: 1.5; text-align: left; }
</style>
