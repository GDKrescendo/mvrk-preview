<?php
/**
 * Page: Our Story — the maverick tribute + responsible-use commitment.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$hero = MVRK_URI . '/assets/img/products/hero-cherry.webp';
$principles = array(
	array( 'shield-check', 'Honest labeling', 'We tell you exactly what\'s in the jar and how it\'s dosed — no inflated claims, no fine-print games.' ),
	array( 'target', 'Dosing transparency', 'Every tablet is scored and measured so a serving is predictable. Control is the whole point.' ),
	array( 'leaf', 'Adults, on purpose', 'Strictly 21+. We\'d rather lose a sale than put this in the wrong hands.' ),
);
?>
<main id="main">
	<section class="story-hero">
		<div class="container-mvrk story-hero__grid">
			<div class="reveal">
				<p class="eyebrow"><?php esc_html_e( 'Our story', 'mvrk' ); ?></p>
				<h1 class="story-hero__title"><?php esc_html_e( 'Named for a maverick.', 'mvrk' ); ?></h1>
				<p class="story-hero__lead"><?php esc_html_e( 'MVRK isn\'t a marketing word we picked off a list. It\'s a tribute — to someone who did things his own way, who stood out, who refused to be ordinary. A star, in his own right.', 'mvrk' ); ?></p>
			</div>
			<div class="story-hero__visual reveal">
				<img src="<?php echo esc_url( $hero ); ?>" alt="MVRK product" width="360" height="360" class="story-hero__img" loading="eager" />
			</div>
		</div>
	</section>

	<section class="section-pad">
		<div class="container-mvrk story-body reveal">
			<!-- CLIENT: confirm the brother's details before launch (name, what he starred in,
			     in-recovery vs. passed). Written to honor him without using his struggle to sell. -->
			<p><?php esc_html_e( 'The maverick behind this name was the kind of person who lit up a room and outworked everyone in it. Talented. Magnetic. The one people remembered. He was also human — and like so many people who shine the brightest, his road wasn\'t a straight line.', 'mvrk' ); ?></p>
			<p><?php echo wp_kses_post( __( 'We won\'t pretend otherwise, and we won\'t dress it up. We carry his name because of who he <em>was</em>, not in spite of anything. The independence, the refusal to settle, the move-different energy — that\'s what MVRK is built on.', 'mvrk' ) ); ?></p>
			<p><?php esc_html_e( 'It\'s also why we take the responsible side of this seriously. A product like ours demands respect: honest dosing, clear limits, and a hard line on who it\'s for. Carrying a maverick\'s name means earning it — every jar, every label, every customer.', 'mvrk' ); ?></p>
		</div>
	</section>

	<section class="section-pad principles">
		<div class="container-mvrk">
			<header class="sec-head reveal">
				<p class="eyebrow"><?php esc_html_e( 'The standard we hold', 'mvrk' ); ?></p>
				<h2 class="sec-head__title"><?php esc_html_e( 'Respect built into the brand.', 'mvrk' ); ?></h2>
			</header>
			<div class="principles__grid reveal" data-stagger>
				<?php foreach ( $principles as $p ) : ?>
					<div class="principle card">
						<span class="principle__icon"><?php mvrk_icon( $p[0], 'ico-lg' ); ?></span>
						<h3 class="principle__title"><?php echo esc_html( $p[1] ); ?></h3>
						<p class="principle__body"><?php echo esc_html( $p[2] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
			<p class="principles__foot reveal">
				<?php
				printf(
					/* translators: %s: phone link */
					esc_html__( 'If you or someone you love is struggling, you\'re not alone — call or text the SAMHSA National Helpline at %s (free, confidential, 24/7).', 'mvrk' ),
					'<a href="tel:18006624357">1-800-662-4357</a>'
				);
				?>
			</p>
		</div>
	</section>

	<section class="cta section-pad">
		<div class="container-mvrk cta__inner reveal">
			<p class="eyebrow"><?php esc_html_e( '21+ only', 'mvrk' ); ?></p>
			<h2 class="cta__heading"><?php esc_html_e( 'Move different.', 'mvrk' ); ?></h2>
			<p class="cta__body"><?php esc_html_e( 'Precision-dosed tablets for adults who want control and consistency. Built with respect — for the name, and for you.', 'mvrk' ); ?></p>
			<div class="cta__actions">
				<a href="<?php echo esc_url( mvrk_shop_url() ); ?>" class="btn btn-primary"><?php esc_html_e( 'Shop the Lineup', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>" class="btn btn-secondary"><?php esc_html_e( 'Responsible use', 'mvrk' ); ?></a>
			</div>
		</div>
	</section>
</main>

<style>
	.story-hero { padding-block: clamp(2.5rem, 6vw, 5rem); }
	.story-hero__grid { display: grid; gap: clamp(2rem, 5vw, 4rem); align-items: center; grid-template-columns: 1fr; }
	.story-hero__title { font-size: var(--text-display); font-weight: 800; margin: 0.5rem 0 1.25rem; }
	.story-hero__lead { color: var(--color-muted); font-size: var(--text-lead); max-width: 34rem; }
	.story-hero__visual { display: grid; place-items: center; }
	.story-hero__img { width: min(70%, 22rem); height: auto; filter: drop-shadow(0 24px 40px oklch(0.05 0.03 25 / 0.5)); }
	@media (min-width: 1024px) { .story-hero__grid { grid-template-columns: 1.1fr 0.9fr; } }
	.story-body { max-width: 44rem; margin-inline: auto; display: grid; gap: 1.5rem; }
	.story-body p { font-size: var(--text-lead); color: var(--color-ink); line-height: 1.7; }
	.story-body em { color: var(--color-accent); font-style: normal; }
	.principles { background: var(--color-base); }
	.principles__grid { display: grid; gap: 1.25rem; grid-template-columns: 1fr; }
	.principle { padding: 1.75rem; }
	.principle__icon { display: inline-grid; place-items: center; width: 3rem; height: 3rem; margin-bottom: 1.1rem; border-radius: 0.75rem; background: var(--color-accent-soft); color: var(--color-accent); }
	.principle__title { font-size: 1.2rem; margin-bottom: 0.5rem; }
	.principle__body { color: var(--color-muted); font-size: 0.92rem; }
	.principles__foot { margin-top: 2.5rem; text-align: center; color: var(--color-muted); font-size: 0.95rem; }
	.principles__foot a { color: var(--color-accent); font-weight: 600; }
	@media (min-width: 768px) { .principles__grid { grid-template-columns: repeat(3, 1fr); } }
</style>
<?php
get_footer();
