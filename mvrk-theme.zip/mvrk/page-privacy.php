<?php
/**
 * Page: Privacy Policy (template — attorney review required).
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$biz = mvrk_get( 'business' );
?>
<main id="main" class="section-pad">
	<div class="container-mvrk legal__inner">
		<p class="eyebrow"><?php esc_html_e( 'Legal', 'mvrk' ); ?></p>
		<h1 class="legal__title"><?php esc_html_e( 'Privacy Policy', 'mvrk' ); ?></h1>
		<p class="legal__updated"><?php esc_html_e( 'Last updated: June 2026', 'mvrk' ); ?></p>
		<div class="legal__note"><?php printf( esc_html__( 'Template policy — %s should have this reviewed by legal counsel and tailored to its actual data, payment, and analytics practices before launch.', 'mvrk' ), esc_html( $biz['legal_name'] ) ); ?></div>

		<h2><?php esc_html_e( 'Overview', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'This Privacy Policy explains how %s ("we", "us") collects, uses, and protects information when you visit our website, enter our giveaway, or purchase our products.', 'mvrk' ), esc_html( $biz['legal_name'] ) ); ?></p>

		<h2><?php esc_html_e( 'Information we collect', 'mvrk' ); ?></h2>
		<ul>
			<li><strong><?php esc_html_e( 'Contact details', 'mvrk' ); ?></strong> <?php esc_html_e( 'you provide via forms (name, email, phone, message).', 'mvrk' ); ?></li>
			<li><strong><?php esc_html_e( 'Giveaway entries', 'mvrk' ); ?></strong> <?php esc_html_e( 'including your name, email, optional phone, and any receipt image you upload.', 'mvrk' ); ?></li>
			<li><strong><?php esc_html_e( 'Order information', 'mvrk' ); ?></strong> <?php esc_html_e( 'processed through our store and payment provider.', 'mvrk' ); ?></li>
			<li><strong><?php esc_html_e( 'Age verification', 'mvrk' ); ?></strong> <?php esc_html_e( '— a confirmation that you are 21+, stored locally in your browser.', 'mvrk' ); ?></li>
			<li><strong><?php esc_html_e( 'Usage data', 'mvrk' ); ?></strong> <?php esc_html_e( 'such as pages visited, collected through analytics cookies where enabled.', 'mvrk' ); ?></li>
		</ul>

		<h2><?php esc_html_e( 'How we use it', 'mvrk' ); ?></h2>
		<ul>
			<li><?php esc_html_e( 'To respond to inquiries, administer the giveaway, and fulfill orders.', 'mvrk' ); ?></li>
			<li><?php esc_html_e( 'To verify eligibility (age, location) and contact winners.', 'mvrk' ); ?></li>
			<li><?php esc_html_e( 'To improve our site and products, and comply with legal obligations.', 'mvrk' ); ?></li>
		</ul>

		<h2><?php esc_html_e( 'Sharing', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'We do not sell your personal information. We share data only with service providers (payment, shipping, email, analytics) as needed to operate, and when required by law.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( 'Your choices', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'You may request access to, correction of, or deletion of your personal information by emailing %s. You can disable cookies in your browser settings.', 'mvrk' ), '<a href="mailto:' . esc_attr( $biz['email'] ) . '">' . esc_html( $biz['email'] ) . '</a>' ); ?></p>

		<h2><?php esc_html_e( 'Children', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'Our site and products are intended only for adults 21 and older. We do not knowingly collect information from anyone under 21.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( 'Contact', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'Questions about this policy? Email %s.', 'mvrk' ), '<a href="mailto:' . esc_attr( $biz['email'] ) . '">' . esc_html( $biz['email'] ) . '</a>' ); ?></p>
	</div>
</main>
<?php
get_footer();
