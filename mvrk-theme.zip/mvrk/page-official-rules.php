<?php
/**
 * Page: Official Rules (sweepstakes). TEMPLATE — must be reviewed and
 * finalized by the client's attorney before launch.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$biz = mvrk_get( 'business' );
?>
<main id="main" class="section-pad">
	<div class="container-mvrk legal__inner">
		<p class="eyebrow"><?php esc_html_e( 'Sweepstakes', 'mvrk' ); ?></p>
		<h1 class="legal__title"><?php esc_html_e( 'MVRK Monthly Giveaway — Official Rules', 'mvrk' ); ?></h1>
		<p class="legal__updated"><?php esc_html_e( 'Last updated: June 2026', 'mvrk' ); ?></p>

		<div class="legal__note">
			<?php esc_html_e( 'TEMPLATE — these rules are a starting point and MUST be reviewed, completed, and approved by the client\'s attorney before the giveaway goes live. IMPORTANT: this promotion requires a purchase to enter (no free entry method). A prize draw that combines a purchase, chance, and a prize may be treated as an illegal lottery in many U.S. states; counsel should confirm legality and whether a free alternate method of entry is required. State registration/bonding may also apply (e.g., NY, FL). Confirm prize value, eligible states, and sponsor details.', 'mvrk' ); ?>
		</div>

		<p><strong><?php esc_html_e( 'VOID WHERE PROHIBITED. OPEN ONLY TO LEGAL U.S. RESIDENTS 21 YEARS OF AGE OR OLDER IN ELIGIBLE STATES. A QUALIFYING PURCHASE AND VALID RECEIPT ARE REQUIRED TO ENTER.', 'mvrk' ); ?></strong></p>

		<h2><?php esc_html_e( '1. Sponsor', 'mvrk' ); ?></h2>
		<p><?php echo esc_html( $biz['legal_name'] ); ?> (&ldquo;Sponsor&rdquo;). [FILL IN full legal address.]</p>

		<h2><?php esc_html_e( '2. Eligibility', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'The MVRK Monthly Giveaway (the "Promotion") is open only to legal residents of the United States who are 21 years of age or older at time of entry and who reside in a state where the product and this Promotion are lawful. Employees of Sponsor and their immediate family/household members are not eligible. Void in any state where 7-hydroxymitragynine products or this type of promotion are prohibited or restricted, and where otherwise prohibited by law.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '3. Promotion period', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'The Promotion runs in monthly entry periods. Each monthly period begins at 12:00:00 a.m. ET on the first day of the calendar month and ends at 11:59:59 p.m. ET on the last day of that month. Entries are tied to the month in which they are received. [Confirm time zone and exact dates.]', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '4. How to enter', 'mvrk' ); ?></h2>
		<p><?php printf( /* translators: %s: email */ esc_html__( 'To enter, email your name and a valid proof-of-purchase (a photo of your receipt) for an MVRK product purchased during the entry period to %s. A qualifying purchase and verifiable proof are required; entries without a valid, verifiable proof of purchase will not be accepted.', 'mvrk' ), esc_html( $biz['email'] ) ); ?></p>
		<p><?php esc_html_e( 'Limit one (1) entry per person per monthly period. Entries that are incomplete, fraudulent, or that contain an unverifiable or duplicate receipt may be disqualified. Sponsor reviews and verifies every receipt before the entry is added to that month\'s entrant pool.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '5. Winner selection & the draw', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'On or shortly after the end of each monthly period, Sponsor will select one (1) potential winner from among all eligible, verified entries for that month in a random drawing conducted by the Sponsor on video. The on-site "wheel" is a visual representation of entrants only; the official winner is the entrant selected in the recorded drawing. Odds of winning depend on the number of eligible entries received.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '6. Prize', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'Each monthly prize is: [FILL IN — e.g., one (1) jar of MVRK product, winner\'s choice of available line and flavor]. Approximate retail value (ARV): [FILL IN]. Prize is non-transferable; no cash equivalent or substitution except by Sponsor. Prize is awarded only to a verified winner who meets all eligibility requirements, including age (21+) and a deliverable address in an eligible state.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '7. Winner notification', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'The potential winner will be notified by email and/or phone and may be required to confirm eligibility (including proof of age) and provide a shipping address within [FILL IN] days. If a potential winner cannot be contacted, declines, is ineligible, or fails to respond, the prize may be forfeited and an alternate winner selected.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '8. Publicity & privacy', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'The winner\'s first name and last initial may be displayed publicly (including in the monthly draw video and on the Winners page). Information collected is used to administer the Promotion in accordance with our Privacy Policy.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '9. General conditions', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'By entering, participants agree to these Official Rules and the decisions of the Sponsor, which are final. Sponsor may disqualify any entrant who tampers with the entry process or violates these rules, and may modify, suspend, or cancel the Promotion if it cannot be run as planned. Sponsor is not responsible for lost, late, or misdirected entries. Released parties are not liable for any harm arising from participation or use of any prize.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '10. Winners list', 'mvrk' ); ?></h2>
		<p><?php printf( /* translators: %s: email */ esc_html__( 'For the list of recent winners, see our Winners page, or email %s.', 'mvrk' ), '<a href="mailto:' . esc_attr( $biz['email'] ) . '">' . esc_html( $biz['email'] ) . '</a>' ); ?></p>
	</div>
</main>
<?php
get_footer();
