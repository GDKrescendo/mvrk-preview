<?php
/**
 * Front page (homepage).
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$biz      = mvrk_get( 'business' );
$nga      = mvrk_get( 'specs.nga' );
$products = mvrk_products();
$hero_img = MVRK_URI . '/assets/img/products/hero-cherry.webp';

$values = array(
	array( 'target', 'Measured by Design', 'Every tablet is precision-dosed and scored for quarter-servings — so you know exactly what you\'re taking, every time.' ),
	array( 'package', 'Built for Real Routines', 'No prep, no mess, no guesswork. A compact tablet that fits how you actually live.' ),
	array( 'layers', 'Consistency You Can Feel', 'Each serving is repeatable and predictable. Same format, same control, jar after jar.' ),
	array( 'shield-check', 'Honest About What This Is', 'We don\'t overhype or make promises we can\'t keep. We tell you what\'s in the jar and how to use it responsibly.' ),
);
?>

<?php mvrk_disclaimer( 'strip' ); ?>

<main id="main">

	<!-- HERO -->
	<section class="hero">
		<div class="container-mvrk hero__grid">
			<div class="hero__copy">
				<p class="eyebrow hero__eyebrow"><?php esc_html_e( 'Precision-dosed · 21+ only', 'mvrk' ); ?></p>
				<h1 class="hero__title">Think like a<br /><span class="hero__accent">maverick.</span></h1>
				<p class="hero__lead">Measured strength. A clean, scored tablet built for control — no guessing, no mess, the same serving every time.</p>
				<div class="hero__actions">
					<a href="<?php echo esc_url( mvrk_shop_url() ); ?>" class="btn btn-primary"><?php esc_html_e( 'Shop the Lineup', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right' ); ?></a>
					<a href="<?php echo esc_url( home_url( '/giveaway/' ) ); ?>" class="btn btn-secondary"><?php esc_html_e( 'Win free product', 'mvrk' ); ?></a>
				</div>
				<dl class="hero__specs">
					<div><dt><?php echo esc_html( $nga['per_tab'] ); ?>mg</dt><dd>per tablet</dd></div>
					<div><dt><?php echo esc_html( $nga['serving'] ); ?>mg</dt><dd>per <?php echo esc_html( $nga['fraction'] ); ?></dd></div>
					<div><dt><?php echo esc_html( $nga['servings'] ); ?></dt><dd>servings / jar</dd></div>
				</dl>
			</div>
			<div class="hero__visual">
				<div class="hero__glow" aria-hidden="true"></div>
				<img src="<?php echo esc_url( $hero_img ); ?>" alt="MVRK Next Generation Alkaloids 300mg tablet, Cherry flavor" width="480" height="480" class="hero__img" fetchpriority="high" />
			</div>
		</div>
	</section>

	<?php mvrk_marquee( array( 'Precision-Dosed', '300MG Tablets', 'Cherry', 'Blue Razz', 'Measured by Design', '21+ Only', 'Made for Mavericks' ) ); ?>

	<!-- VALUES -->
	<section class="section-pad">
		<div class="container-mvrk">
			<header class="sec-head reveal">
				<p class="eyebrow"><?php esc_html_e( 'Why MVRK', 'mvrk' ); ?></p>
				<h2 class="sec-head__title"><?php esc_html_e( 'Built different, on purpose.', 'mvrk' ); ?></h2>
			</header>
			<div class="values reveal" data-stagger>
				<?php foreach ( $values as $v ) : ?>
					<div class="value card">
						<span class="value__icon"><?php mvrk_icon( $v[0], 'ico-lg' ); ?></span>
						<h3 class="value__title"><?php echo esc_html( $v[1] ); ?></h3>
						<p class="value__body"><?php echo esc_html( $v[2] ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- LINEUP -->
	<section id="lineup" class="section-pad lineup">
		<div class="container-mvrk">
			<header class="sec-head sec-head--row reveal">
				<div>
					<p class="eyebrow"><?php esc_html_e( 'The lineup', 'mvrk' ); ?></p>
					<h2 class="sec-head__title"><?php esc_html_e( 'Choose your MVRK formula.', 'mvrk' ); ?></h2>
				</div>
				<a href="<?php echo esc_url( mvrk_shop_url() ); ?>" class="lineup__all"><?php esc_html_e( 'View full shop', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right', 'ico-sm' ); ?></a>
			</header>
			<div class="lineup__grid reveal" data-stagger>
				<?php foreach ( $products as $p ) : ?>
					<?php mvrk_product_card( $p ); ?>
				<?php endforeach; ?>
			</div>
			<?php mvrk_where_to_buy( 'lineup__wtb reveal' ); ?>
		</div>
	</section>

	<!-- GIVEAWAY TEASER -->
	<section class="section-pad giveaway-teaser">
		<div class="container-mvrk">
			<header class="sec-head giveaway-teaser__head reveal">
				<p class="eyebrow"><?php esc_html_e( 'Every month · free product · 21+', 'mvrk' ); ?></p>
				<h2 class="giveaway-teaser__title"><?php esc_html_e( 'Win 100 free — new winner picked monthly.', 'mvrk' ); ?></h2>
				<p class="giveaway-teaser__body"><?php esc_html_e( 'One winner. 100 tablets. Every month. Buy MVRK, email your proof of purchase to info@mvrktabz.com, and your name joins the wheel — the owner draws a new winner on video every month.', 'mvrk' ); ?></p>
			</header>

			<?php
			// Prefer the single dual-bottle flyer; fall back to the two singles until it's added.
			$mvrk_single = MVRK_DIR . '/assets/img/giveaway-flyer.jpg';
			if ( file_exists( $mvrk_single ) ) {
				$mvrk_flyers = array(
					array( 'giveaway-flyer.jpg', __( 'MVRK 7-Hydroxy 100mg — Cherry & Blue Razz. Win 100 free every month.', 'mvrk' ), 'is-wide' ),
				);
			} else {
				$mvrk_flyers = array(
					array( 'giveaway-flyer-blue.jpg', __( 'MVRK giveaway — Win 100 tablets every month (blue)', 'mvrk' ), '' ),
					array( 'giveaway-flyer-red.jpg', __( 'MVRK giveaway — Win 100 tablets every month (red)', 'mvrk' ), '' ),
				);
			}
			?>
			<div class="giveaway-flyers reveal" data-stagger>
				<?php
				foreach ( $mvrk_flyers as $mvrk_flyer ) :
					$mvrk_flyer_path = MVRK_DIR . '/assets/img/' . $mvrk_flyer[0];
					if ( ! file_exists( $mvrk_flyer_path ) ) {
						continue; // skip until the asset is added
					}
					?>
					<a href="<?php echo esc_url( home_url( '/giveaway/' ) ); ?>" class="giveaway-flyer <?php echo esc_attr( $mvrk_flyer[2] ); ?>">
						<img src="<?php echo esc_url( MVRK_URI . '/assets/img/' . $mvrk_flyer[0] ); ?>" alt="<?php echo esc_attr( $mvrk_flyer[1] ); ?>" loading="lazy" />
					</a>
				<?php endforeach; ?>
			</div>

			<div class="giveaway-teaser__actions reveal">
				<a href="<?php echo esc_url( home_url( '/giveaway/' ) ); ?>" class="btn btn-primary"><?php esc_html_e( 'Enter the giveaway', 'mvrk' ); ?> <?php mvrk_icon( 'ticket' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/winners/' ) ); ?>" class="btn btn-secondary"><?php esc_html_e( 'See past winners', 'mvrk' ); ?></a>
			</div>
		</div>
	</section>

	<!-- DOSED -->
	<section class="section-pad dosed">
		<div class="container-mvrk dosed__grid">
			<div class="dosed__copy reveal">
				<p class="eyebrow"><?php esc_html_e( 'How it\'s dosed', 'mvrk' ); ?></p>
				<h2 class="dosed__title"><?php esc_html_e( 'No guesswork. Just a clean, scored tablet.', 'mvrk' ); ?></h2>
				<p class="dosed__lead"><?php esc_html_e( 'Each MVRK tablet is precision-pressed and scored into quarters, so a single serving is predictable every time — in a format you can actually carry. Next Generation Alkaloids run 300mg (75mg per quarter); 7-Hydroxy tablets run 100mg (25mg per quarter).', 'mvrk' ); ?></p>
				<ul class="dosed__list">
					<li><?php mvrk_icon( 'check-circle' ); ?> Precision-pressed tablets, scored for control</li>
					<li><?php mvrk_icon( 'check-circle' ); ?> 1/4-tablet servings, measured and repeatable</li>
					<li><?php mvrk_icon( 'check-circle' ); ?> 40 servings per jar</li>
					<li><?php mvrk_icon( 'check-circle' ); ?> Start low, go slow — know your own limit</li>
				</ul>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>" class="dosed__link"><?php esc_html_e( 'Read our responsible-use guide', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right', 'ico-sm' ); ?></a>
			</div>
			<div class="dosed__stat reveal" data-stagger>
				<div class="stat-card"><span class="stat-card__num">300</span><span class="stat-card__unit">mg · Next Gen Alkaloids</span></div>
				<div class="stat-card"><span class="stat-card__num">100</span><span class="stat-card__unit">mg · 7-Hydroxy</span></div>
				<div class="stat-card stat-card--wide"><span class="stat-card__num">40</span><span class="stat-card__unit">servings in every jar</span></div>
			</div>
		</div>
	</section>

	<!-- STORY TEASER -->
	<section class="section-pad story-teaser">
		<div class="container-mvrk story-teaser__inner reveal">
			<p class="eyebrow"><?php esc_html_e( 'The name', 'mvrk' ); ?></p>
			<h2 class="story-teaser__title"><?php esc_html_e( 'MVRK is a tribute to a maverick.', 'mvrk' ); ?></h2>
			<p class="story-teaser__body"><?php esc_html_e( 'The brand carries the spirit of someone who lived it his own way — a star who refused the ordinary. That same independence is why we hold ourselves to a higher standard: honest labeling, real dosing transparency, and a hard line on responsible, adults-only use.', 'mvrk' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/story/' ) ); ?>" class="btn btn-secondary"><?php esc_html_e( 'Read the full story', 'mvrk' ); ?></a>
		</div>
	</section>

	<!-- TRUST BAR -->
	<section class="section-pad trustbar-section">
		<div class="container-mvrk">
			<header class="sec-head reveal" style="text-align:center;margin-inline:auto">
				<p class="eyebrow"><?php esc_html_e( 'Premium quality · Lab tested · Top shelf', 'mvrk' ); ?></p>
				<h2 class="sec-head__title"><?php esc_html_e( 'Built to a higher standard.', 'mvrk' ); ?></h2>
			</header>
			<div class="trustbar reveal" data-stagger>
				<?php
				$trust = array(
					array( 'shield-check', 'Lab Tested' ),
					array( 'leaf', 'Premium Ingredients' ),
					array( 'target', 'Precision-Dosed' ),
					array( 'shield', 'Made in USA' ),
					array( 'check-circle', '21+ Only' ),
				);
				foreach ( $trust as $t ) :
					?>
					<div class="trustbar__item">
						<span class="trustbar__icon"><?php mvrk_icon( $t[0], 'ico-lg' ); ?></span>
						<span class="trustbar__label"><?php echo esc_html( $t[1] ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<!-- CTA -->
	<section class="cta section-pad">
		<div class="container-mvrk cta__inner reveal">
			<p class="eyebrow"><?php esc_html_e( '21+ only', 'mvrk' ); ?></p>
			<h2 class="cta__heading"><?php esc_html_e( 'Take control with MVRK.', 'mvrk' ); ?></h2>
			<p class="cta__body"><?php esc_html_e( 'Choose your line. Pick your flavor. Precision-dosed for consistency you can actually feel — built for adults who want to know exactly what they\'re taking.', 'mvrk' ); ?></p>
			<div class="cta__actions">
				<a href="<?php echo esc_url( mvrk_shop_url() ); ?>" class="btn btn-primary"><?php esc_html_e( 'Shop the Lineup', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>" class="btn btn-secondary"><?php esc_html_e( 'How to use responsibly', 'mvrk' ); ?></a>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
