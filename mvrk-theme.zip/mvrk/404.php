<?php
/**
 * 404 template.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main">
	<section class="nf">
		<div class="container-mvrk nf__inner">
			<p class="nf__code">404</p>
			<h1 class="nf__title"><?php esc_html_e( 'This one went off-grid.', 'mvrk' ); ?></h1>
			<p class="nf__body"><?php esc_html_e( 'The page you\'re after has moved or never existed. Let\'s get you back to the lineup.', 'mvrk' ); ?></p>
			<div class="nf__actions">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary"><?php esc_html_e( 'Back home', 'mvrk' ); ?></a>
				<a href="<?php echo esc_url( mvrk_shop_url() ); ?>" class="btn btn-secondary"><?php esc_html_e( 'Shop MVRK', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right' ); ?></a>
			</div>
		</div>
	</section>
</main>
<style>
	.nf { min-height: 60vh; display: grid; place-items: center; padding-block: 5rem; text-align: center; }
	.nf__code { font-family: var(--font-display); font-size: clamp(5rem, 18vw, 10rem); line-height: 1; color: var(--color-accent); }
	.nf__title { font-size: var(--text-h1); margin: 0.5rem 0 1rem; }
	.nf__body { color: var(--color-muted); font-size: var(--text-lead); max-width: 30rem; margin: 0 auto 2rem; }
	.nf__actions { display: flex; gap: 0.85rem; justify-content: center; flex-wrap: wrap; }
</style>
<?php
get_footer();
