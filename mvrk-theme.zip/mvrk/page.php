<?php
/**
 * Default page template — renders editor content inside the legal/prose shell.
 * Used for any WordPress Page that doesn't have a more specific template.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<main id="main" class="section-pad">
	<div class="container-mvrk legal__inner">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<p class="eyebrow"><?php esc_html_e( 'MVRK', 'mvrk' ); ?></p>
			<h1 class="legal__title"><?php the_title(); ?></h1>
			<div class="mvrk-prose"><?php the_content(); ?></div>
		<?php endwhile; ?>
	</div>
</main>
<?php
get_footer();
