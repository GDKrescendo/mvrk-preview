/* MVRK theme — interactions & motion. Globals: gsap, ScrollTrigger, Lenis (CDN). */
(function () {
  "use strict";

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Age gate (21+) ---------- */
  (function ageGate() {
    var KEY = "mvrk-age-verified";
    var gate = document.getElementById("age-gate");
    if (!gate) return;
    if (localStorage.getItem(KEY) === "true") return;
    gate.hidden = false;
    document.documentElement.style.overflow = "hidden";
    var yes = document.getElementById("age-yes");
    var no = document.getElementById("age-no");
    if (yes) {
      yes.focus();
      yes.addEventListener("click", function () {
        localStorage.setItem(KEY, "true");
        gate.hidden = true;
        document.documentElement.style.overflow = "";
      });
    }
    if (no) {
      no.addEventListener("click", function () {
        window.location.href = "https://www.google.com";
      });
    }
  })();

  /* ---------- Mobile nav ---------- */
  (function mobileNav() {
    var toggle = document.getElementById("nav-toggle");
    var close = document.getElementById("nav-close");
    var nav = document.getElementById("mobile-nav");
    if (!nav) return;
    function open() {
      nav.hidden = false;
      if (toggle) toggle.setAttribute("aria-expanded", "true");
      document.documentElement.style.overflow = "hidden";
    }
    function shut() {
      nav.hidden = true;
      if (toggle) toggle.setAttribute("aria-expanded", "false");
      document.documentElement.style.overflow = "";
    }
    if (toggle) toggle.addEventListener("click", open);
    if (close) close.addEventListener("click", shut);
    nav.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", shut);
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !nav.hidden) shut();
    });
  })();

  /* ---------- Sticky header state ---------- */
  (function header() {
    var el = document.getElementById("site-header");
    if (!el) return;
    function onScroll() {
      el.classList.toggle("is-scrolled", window.scrollY > 12);
    }
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  })();

  /* ---------- In-page anchor scrolling (native, no scroll hijack) ---------- */
  (function anchors() {
    document.querySelectorAll('a[href^="#"]').forEach(function (a) {
      a.addEventListener("click", function (e) {
        var id = a.getAttribute("href");
        if (id && id.length > 1) {
          var target = document.querySelector(id);
          if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
          }
        }
      });
    });
  })();

  /* ---------- Scroll reveals ---------- */
  (function reveals() {
    if (typeof window.gsap === "undefined") {
      document.querySelectorAll(".reveal").forEach(function (el) {
        el.style.opacity = "1";
        el.style.transform = "none";
      });
      return;
    }
    var gsap = window.gsap;
    var items = gsap.utils.toArray(".reveal");
    if (reduce) {
      items.forEach(function (el) {
        gsap.set(el, { opacity: 1, y: 0 });
      });
      return;
    }
    if (window.ScrollTrigger) gsap.registerPlugin(window.ScrollTrigger);
    items.forEach(function (el) {
      var stagger = el.hasAttribute("data-stagger");
      var children = stagger ? gsap.utils.toArray(":scope > *", el) : [el];
      gsap.set(el, { opacity: 1 });
      gsap.from(children, {
        opacity: 0,
        y: 28,
        duration: 0.7,
        ease: "power2.out",
        stagger: stagger ? 0.1 : 0,
        scrollTrigger: { trigger: el, start: "top 85%" },
      });
    });
  })();
})();
