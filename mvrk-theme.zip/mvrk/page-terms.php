<?php
/**
 * Page: Terms of Service (template — attorney review required).
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
$biz = mvrk_get( 'business' );
$d   = mvrk_get( 'disclaimer' );
?>
<main id="main" class="section-pad">
	<div class="container-mvrk legal__inner">
		<p class="eyebrow"><?php esc_html_e( 'Legal', 'mvrk' ); ?></p>
		<h1 class="legal__title"><?php esc_html_e( 'Terms of Service', 'mvrk' ); ?></h1>
		<p class="legal__updated"><?php esc_html_e( 'Last updated: June 2026', 'mvrk' ); ?></p>
		<div class="legal__note"><?php printf( esc_html__( 'Template terms — %s should have these reviewed and finalized by legal counsel, including jurisdiction-specific shipping and age-restriction language, before launch.', 'mvrk' ), esc_html( $biz['legal_name'] ) ); ?></div>

		<h2><?php esc_html_e( '1. Eligibility & age', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'You must be at least 21 years old to use this site or purchase products. By using the site you represent and warrant that you meet this requirement.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '2. Products & intended use', 'mvrk' ); ?></h2>
		<p><?php echo esc_html( $d['fda'] ); ?> <?php echo esc_html( $d['dependence'] ); ?></p>

		<h2><?php esc_html_e( '3. Shipping & legality', 'mvrk' ); ?></h2>
		<p><?php echo esc_html( $d['shipping'] ); ?> <?php esc_html_e( 'You are responsible for knowing and complying with the laws of your jurisdiction before ordering.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '4. Orders & payment', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'Orders are processed through our store and third-party payment providers. We reserve the right to refuse or cancel any order, including for suspected age misrepresentation or shipment to a restricted area.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '5. Giveaway', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'Participation in the MVRK Monthly Giveaway is governed by its %s, which are incorporated by reference.', 'mvrk' ), '<a href="' . esc_url( home_url( '/official-rules/' ) ) . '">' . esc_html__( 'Official Rules', 'mvrk' ) . '</a>' ); ?></p>

		<h2><?php esc_html_e( '6. Assumption of risk', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'You use our products at your own risk and agree to use them responsibly and as directed. Consult a physician before use, especially if you have a medical condition or take other medications.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '7. Limitation of liability', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'To the fullest extent permitted by law, %s is not liable for any indirect, incidental, or consequential damages arising from use of the site or products.', 'mvrk' ), esc_html( $biz['legal_name'] ) ); ?></p>

		<h2><?php esc_html_e( '8. Changes', 'mvrk' ); ?></h2>
		<p><?php esc_html_e( 'We may update these terms at any time. Continued use of the site constitutes acceptance of the updated terms.', 'mvrk' ); ?></p>

		<h2><?php esc_html_e( '9. Contact', 'mvrk' ); ?></h2>
		<p><?php printf( esc_html__( 'Questions? Email %s.', 'mvrk' ), '<a href="mailto:' . esc_attr( $biz['email'] ) . '">' . esc_html( $biz['email'] ) . '</a>' ); ?></p>
	</div>
</main>
<?php
get_footer();
