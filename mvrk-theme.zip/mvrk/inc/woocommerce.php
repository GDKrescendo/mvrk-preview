<?php
/**
 * WooCommerce integration — disclaimers, corrected spec blocks, COA note.
 * Avoids full template overrides; uses WooCommerce hooks.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Which line is this product — returns the matching spec array.
 *
 * @param WC_Product $product Product.
 */
function mvrk_product_spec( $product ) {
	$name  = $product ? strtolower( $product->get_name() ) : '';
	$specs = mvrk_get( 'specs' );
	if ( false !== strpos( $name, '7-hydroxy' ) || false !== strpos( $name, '7 hydroxy' ) ) {
		return $specs['7hydroxy'];
	}
	return $specs['nga'];
}

/**
 * Disclaimer strip at the top of shop + product pages.
 */
function mvrk_wc_top_disclaimer() {
	if ( function_exists( 'mvrk_disclaimer' ) ) {
		mvrk_disclaimer( 'strip' );
	}
}
add_action( 'woocommerce_before_main_content', 'mvrk_wc_top_disclaimer', 5 );

/**
 * Spec block in the product summary (after price/short description).
 */
function mvrk_wc_spec_block() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$s = mvrk_product_spec( $product );
	echo '<dl class="mvrk-wc-specs">';
	printf( '<div><dt>%s</dt><dd>%dmg</dd></div>', esc_html__( 'Per tablet', 'mvrk' ), (int) $s['per_tab'] );
	printf( '<div><dt>%s</dt><dd>%s — %dmg</dd></div>', esc_html__( 'Serving', 'mvrk' ), esc_html( $s['fraction'] ), (int) $s['serving'] );
	printf( '<div><dt>%s</dt><dd>%d</dd></div>', esc_html__( 'Servings / jar', 'mvrk' ), (int) $s['servings'] );
	echo '</dl>';
	echo '<p class="mvrk-wc-dosing">' . esc_html__( 'Precision-pressed and scored into quarters, so a single serving is predictable every time. Start low, go slow.', 'mvrk' ) . '</p>';
}
add_action( 'woocommerce_single_product_summary', 'mvrk_wc_spec_block', 25 );

/**
 * "Where to buy" note in the product summary (after add-to-cart) and on the shop page.
 */
function mvrk_wc_where_to_buy() {
	if ( function_exists( 'mvrk_where_to_buy' ) ) {
		mvrk_where_to_buy( 'mvrk-wc-wtb' );
	}
}
add_action( 'woocommerce_single_product_summary', 'mvrk_wc_where_to_buy', 35 );
add_action( 'woocommerce_after_shop_loop', 'mvrk_wc_where_to_buy', 20 );

/**
 * COA note + safety disclaimer block after the product summary.
 */
function mvrk_wc_after_summary() {
	echo '<div class="mvrk-wc-coa"><p>';
	if ( function_exists( 'mvrk_icon' ) ) {
		mvrk_icon( 'shield-check', 'ico-sm' );
	}
	echo ' ' . esc_html__( 'Lab-test documents (COA) available on request. For adults 21+ only.', 'mvrk' ) . '</p></div>';
	echo '<div class="container-mvrk mvrk-wc-disc">';
	if ( function_exists( 'mvrk_disclaimer' ) ) {
		mvrk_disclaimer( 'block' );
	}
	echo '</div>';
}
add_action( 'woocommerce_after_single_product_summary', 'mvrk_wc_after_summary', 8 );

/**
 * Sale flash text -> brand tone.
 */
add_filter( 'woocommerce_sale_flash', function () {
	return '<span class="onsale">' . esc_html__( 'Sale', 'mvrk' ) . '</span>';
} );
