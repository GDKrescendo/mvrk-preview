<?php
/**
 * MVRK central config — brand data, disclaimers, product specs.
 * Mirrors the Astro siteData.json. Values marked _PLACEHOLDER must be
 * confirmed with the client (see CLAUDE.md open items). Where possible
 * these are overridable via WordPress options / the Customizer.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the MVRK config array (filterable, cached per request).
 */
function mvrk_config() {
	static $config = null;
	if ( null !== $config ) {
		return $config;
	}

	$config = array(
		'business'   => array(
			'name'        => 'MVRK',
			'legal_name'  => 'MVRK Next-Generation Alkaloids',
			'tagline'     => 'Think Like a Maverick.',
			'sub_tagline' => 'Precision-dosed tablets built for control.',
			'email'       => get_option( 'mvrk_email', 'info@mvrktabz.com' ),
			'phone'       => get_option( 'mvrk_phone', '' ), // empty = hidden until confirmed
			'country'     => 'USA',
			'hours'       => 'Open 24/7 — order anytime',
			'age'         => 21,
		),
		'social'     => array(
			'handle'    => '@MVRKTabz',
			'instagram' => get_option( 'mvrk_instagram', '' ),
			'facebook'  => get_option( 'mvrk_facebook', '' ),
			'youtube'   => get_option( 'mvrk_youtube', '' ),
			'x'         => get_option( 'mvrk_x', '' ),
		),
		// Product lines and their REAL specs (corrected June 2026).
		'specs'      => array(
			'nga'      => array(
				'label'    => 'Next Generation Alkaloids',
				'per_tab'  => 300,
				'serving'  => 75,
				'servings' => 40,
				'fraction' => '1/4 tablet',
			),
			'7hydroxy' => array(
				'label'    => '7-Hydroxy Tablets',
				'per_tab'  => 100,
				'serving'  => 25,
				'servings' => 40,
				'fraction' => '1/4 tablet',
			),
		),
		'disclaimer' => array(
			'short'      => 'For adults 21+. Not for sale to minors. Keep out of reach of children and pets.',
			'fda'        => 'These statements have not been evaluated by the Food and Drug Administration. This product is not intended to diagnose, treat, cure, or prevent any disease.',
			'dependence' => 'This product contains 7-hydroxymitragynine, which acts on opioid receptors and may be habit-forming. Do not exceed the suggested serving. Do not use if pregnant, nursing, or operating heavy machinery. Consult a physician before use, especially if you have a medical condition or take other medications.',
			'shipping'   => 'We do not ship where prohibited by law. It is your responsibility to know the laws in your jurisdiction.',
			'helpline'   => array(
				'label' => 'SAMHSA National Helpline',
				'tel'   => '1-800-662-4357',
				'href'  => 'tel:18006624357',
			),
		),
	);

	return apply_filters( 'mvrk_config', $config );
}

/**
 * Convenience getter using dot notation, e.g. mvrk_get( 'business.email' ).
 */
function mvrk_get( $path, $default = '' ) {
	$value = mvrk_config();
	foreach ( explode( '.', $path ) as $key ) {
		if ( is_array( $value ) && isset( $value[ $key ] ) ) {
			$value = $value[ $key ];
		} else {
			return $default;
		}
	}
	return $value;
}
