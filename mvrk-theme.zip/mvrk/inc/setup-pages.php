<?php
/**
 * Auto-create the theme's content pages on activation, and set a static
 * front page. Idempotent.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pages owned by the theme (rendered by page-{slug}.php templates).
 */
function mvrk_theme_pages() {
	return array(
		'story'           => 'Our Story',
		'responsible-use' => 'Responsible Use',
		'contact'         => 'Contact',
		'official-rules'  => 'Official Rules',
		'privacy'         => 'Privacy Policy',
		'terms'           => 'Terms of Service',
	);
}

/**
 * Create missing pages + a "Home" front page on theme switch.
 */
function mvrk_create_pages() {
	foreach ( mvrk_theme_pages() as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array(
				'post_title'  => $title,
				'post_name'   => $slug,
				'post_status' => 'publish',
				'post_type'   => 'page',
			) );
		}
	}

	// Ensure a static front page exists and is set (so front-page.php shows).
	$home = get_page_by_path( 'home' );
	if ( ! $home ) {
		$home_id = wp_insert_post( array(
			'post_title'  => 'Home',
			'post_name'   => 'home',
			'post_status' => 'publish',
			'post_type'   => 'page',
		) );
	} else {
		$home_id = $home->ID;
	}
	if ( $home_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}
}
add_action( 'after_switch_theme', 'mvrk_create_pages' );
