<?php
/**
 * MVRK template helpers — icons, disclaimers, marquee, social links.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lucide-style inline SVG icons. Echoes the <svg>.
 *
 * @param string $name  Icon key.
 * @param string $class CSS class (default .ico).
 */
function mvrk_icon( $name, $class = 'ico' ) {
	$paths = array(
		'menu'          => '<line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="18" y2="18"/>',
		'x'             => '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
		'arrow-right'   => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
		'arrow-up-right'=> '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
		'chevron-right' => '<path d="m9 18 6-6-6-6"/>',
		'check'         => '<path d="M20 6 9 17l-5-5"/>',
		'check-circle'  => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
		'shield'        => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
		'shield-check'  => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
		'target'        => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
		'layers'        => '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
		'package'       => '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M12 22V12"/>',
		'truck'         => '<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
		'ticket'        => '<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v2"/><path d="M13 17v2"/><path d="M13 11v2"/>',
		'gift'          => '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5"/>',
		'trophy'        => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
		'upload'        => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/>',
		'play'          => '<polygon points="6 3 20 12 6 21 6 3"/>',
		'alert-triangle'=> '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
		'mail'          => '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
		'phone'         => '<path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.06 6.034z"/>',
		'map-pin'       => '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
		'clock'         => '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
		'leaf'          => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6"/>',
		'instagram'     => '<rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>',
		'facebook'      => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
		'youtube'       => '<path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/><path d="m10 15 5-3-5-3z"/>',
		'twitter'       => '<path d="M4 4l11.733 16h4.267l-11.733 -16z"/><path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"/>',
	);

	$inner = isset( $paths[ $name ] ) ? $paths[ $name ] : '';
	printf(
		'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" class="%s" aria-hidden="true">%s</svg>',
		esc_attr( $class ),
		$inner // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG path data.
	);
}

/**
 * Render a disclaimer block.
 *
 * @param string $variant 'strip' or 'block'.
 */
function mvrk_disclaimer( $variant = 'strip' ) {
	$d = mvrk_get( 'disclaimer' );
	if ( 'strip' === $variant ) {
		echo '<aside class="disc-strip" role="note"><div class="container-mvrk disc-strip__inner">';
		mvrk_icon( 'alert-triangle', 'ico disc-strip__icon' );
		echo '<p>' . esc_html( $d['short'] ) . '</p></div></aside>';
		return;
	}
	echo '<aside class="disc-block" role="note" aria-label="Important product disclaimers">';
	echo '<p class="disc-block__lead">';
	mvrk_icon( 'alert-triangle', 'ico' );
	echo ' Important safety information</p>';
	echo '<p>' . esc_html( $d['dependence'] ) . '</p>';
	echo '<p>' . esc_html( $d['fda'] ) . '</p>';
	echo '<p>' . esc_html( $d['shipping'] ) . '</p>';
	echo '</aside>';
}

/**
 * Render a scrolling marquee.
 *
 * @param string[] $items Items to scroll.
 */
function mvrk_marquee( $items ) {
	$loop = array_merge( $items, $items );
	echo '<div class="marquee" aria-hidden="true"><div class="marquee__track">';
	foreach ( $loop as $item ) {
		echo '<span class="marquee__item">' . esc_html( $item ) . '<span class="marquee__dot">&#9670;</span></span>';
	}
	echo '</div></div>';
}

/**
 * Return non-placeholder social links.
 */
function mvrk_social_links() {
	$social = mvrk_get( 'social' );
	$map    = array(
		'instagram' => array( 'instagram', 'Instagram' ),
		'facebook'  => array( 'facebook', 'Facebook' ),
		'youtube'   => array( 'youtube', 'YouTube' ),
		'x'         => array( 'twitter', 'X' ),
	);
	$out = array();
	foreach ( $map as $key => $meta ) {
		if ( ! empty( $social[ $key ] ) && 0 !== strpos( $social[ $key ], '_PLACEHOLDER' ) ) {
			$out[] = array(
				'href'  => $social[ $key ],
				'icon'  => $meta[0],
				'label' => $meta[1],
			);
		}
	}
	return $out;
}

/**
 * Shop URL — WooCommerce shop page if available, else /shop/.
 */
function mvrk_shop_url() {
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'shop' );
		if ( $url ) {
			return $url;
		}
	}
	return home_url( '/shop/' );
}

/**
 * The current giveaway month key, e.g. "2026-06".
 */
function mvrk_current_month() {
	return gmdate( 'Y-m' );
}

/**
 * Human label for a YYYY-MM month key.
 */
function mvrk_month_label( $key ) {
	$ts = strtotime( $key . '-01' );
	return $ts ? gmdate( 'F Y', $ts ) : $key;
}

/**
 * The four MVRK SKUs for marketing cards (homepage lineup, story, etc.).
 * Links resolve to the matching WooCommerce product by slug when it exists,
 * otherwise to the shop. Commerce/pricing lives in WooCommerce.
 */
function mvrk_products() {
	$shop = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );

	$items = array(
		array(
			'name'   => 'Next Generation Alkaloids',
			'flavor' => 'Cherry',
			'line'   => 'Next Generation Alkaloids',
			'img'    => 'next-gen-cherry.webp',
			'accent' => 'cherry',
			'slug'   => 'next-generation-alkaloids',
			'blurb'  => 'A precision-dosed 300mg tablet in a clean cherry profile. Measured, predictable, repeatable.',
		),
		array(
			'name'   => 'Next Generation Alkaloids',
			'flavor' => 'Blue Razz',
			'line'   => 'Next Generation Alkaloids',
			'img'    => 'next-gen-blue-razz.webp',
			'accent' => 'blueRazz',
			'slug'   => 'next-generation-alkaloids-blue-razz-flavor',
			'blurb'  => 'The same 300mg precision format with a bold blue razz profile. Consistency you can feel.',
		),
		array(
			'name'   => '7-Hydroxy Tablets',
			'flavor' => 'Cherry',
			'line'   => '7-Hydroxy',
			'img'    => '7-hydroxy-cherry.webp',
			'accent' => 'cherry',
			'slug'   => '7-hydroxy-tablets',
			'blurb'  => 'Our 100mg 7-Hydroxy tablet in cherry. Compact, carry-anywhere, dosed by the quarter.',
		),
		array(
			'name'   => '7-Hydroxy Tablets',
			'flavor' => 'Blue Razz',
			'line'   => '7-Hydroxy',
			'img'    => '7-hydroxy-blue-razz.webp',
			'accent' => 'blueRazz',
			'slug'   => '7-hydroxy-tablets-blue-razz-flavor',
			'blurb'  => '7-Hydroxy in blue razz at 100mg per tablet. The same clean, no-guesswork serving in every jar.',
		),
	);

	foreach ( $items as &$item ) {
		$item['image_url'] = MVRK_URI . '/assets/img/products/' . $item['img'];
		$item['price']     = '';
		$link              = $shop;
		if ( function_exists( 'get_page_by_path' ) ) {
			$wc = get_page_by_path( $item['slug'], OBJECT, 'product' );
			if ( $wc ) {
				$link = get_permalink( $wc );
				// Pull the live WooCommerce price so there's a single source of truth.
				if ( function_exists( 'wc_get_product' ) ) {
					$product = wc_get_product( $wc->ID );
					if ( $product ) {
						$item['price'] = $product->get_price_html();
					}
				}
			}
		}
		$item['url'] = $link;
	}
	unset( $item );

	return $items;
}

/**
 * Render a marketing product card.
 */
function mvrk_product_card( $p, $eager = false ) {
	?>
	<article class="pcard card" data-accent="<?php echo esc_attr( $p['accent'] ); ?>">
		<a href="<?php echo esc_url( $p['url'] ); ?>" class="pcard__media" aria-label="<?php echo esc_attr( $p['name'] . ' — ' . $p['flavor'] ); ?>">
			<img src="<?php echo esc_url( $p['image_url'] ); ?>" alt="<?php echo esc_attr( $p['name'] . ', ' . $p['flavor'] . ' flavor' ); ?>" width="300" height="300" class="pcard__img" loading="<?php echo $eager ? 'eager' : 'lazy'; ?>" />
			<span class="pcard__flavor"><?php echo esc_html( $p['flavor'] ); ?></span>
		</a>
		<div class="pcard__body">
			<p class="pcard__line"><?php echo esc_html( $p['line'] ); ?></p>
			<h3 class="pcard__name"><a href="<?php echo esc_url( $p['url'] ); ?>"><?php echo esc_html( $p['name'] ); ?></a></h3>
			<?php if ( ! empty( $p['price'] ) ) : ?>
				<p class="pcard__price"><?php echo wp_kses_post( $p['price'] ); ?></p>
			<?php endif; ?>
			<p class="pcard__blurb"><?php echo esc_html( $p['blurb'] ); ?></p>
			<div class="pcard__foot">
				<a href="<?php echo esc_url( $p['url'] ); ?>" class="pcard__details"><?php esc_html_e( 'Details', 'mvrk' ); ?> <?php mvrk_icon( 'arrow-right', 'ico-sm' ); ?></a>
				<a href="<?php echo esc_url( $p['url'] ); ?>" class="btn btn-primary pcard__buy"><?php esc_html_e( 'Buy', 'mvrk' ); ?></a>
			</div>
		</div>
	</article>
	<?php
}

/**
 * "Where to buy" note — email for local availability or buy online.
 *
 * @param string $class Extra CSS class.
 */
function mvrk_where_to_buy( $class = '' ) {
	$email = mvrk_get( 'business.email', 'info@mvrktabz.com' );
	printf(
		'<p class="mvrk-wtb %s">%s <a href="mailto:%s">%s</a> %s</p>',
		esc_attr( $class ),
		esc_html__( 'Want it locally? Email', 'mvrk' ),
		esc_attr( $email ),
		esc_html( $email ),
		esc_html__( 'to find a store near you — or buy online.', 'mvrk' )
	);
}
