<?php
/**
 * SEO meta — per-page description, canonical, Open Graph, Twitter card, and
 * Organization + Product JSON-LD. (WordPress core only emits <title>.)
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Per-page meta description.
 */
function mvrk_seo_description() {
	$brand = 'MVRK makes precision-dosed botanical tablets — Next Generation Alkaloids (300mg) and 7-Hydroxy (100mg), scored for control. For adults 21+.';

	if ( is_front_page() ) {
		return $brand . ' Win 100 free every month.';
	}

	if ( function_exists( 'is_shop' ) && ( is_shop() || is_product_category() ) ) {
		return 'Shop MVRK — precision-dosed 7-Hydroxy and Next Generation Alkaloid tablets in Cherry and Blue Razz. Adults 21+.';
	}

	if ( is_singular() ) {
		$post = get_queried_object();

		// WooCommerce product → short/long description.
		if ( function_exists( 'is_product' ) && is_product() && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $post->ID );
			if ( $product ) {
				$d = $product->get_short_description() ? $product->get_short_description() : $product->get_description();
				$d = trim( wp_strip_all_tags( $d ) );
				if ( $d ) {
					return wp_trim_words( $d, 30 );
				}
			}
		}

		// Per-slug descriptions for the custom page templates (content lives in PHP, not the editor).
		$map = array(
			'story'           => 'The story behind MVRK — named for a maverick. Honest labeling, real dosing transparency, and a hard line on responsible, adults-only use.',
			'responsible-use' => 'How to use MVRK responsibly — dosing, dependence risk, and who should not use it. For adults 21+ only.',
			'contact'         => 'Get in touch with MVRK — product questions, wholesale, lab results, or where to buy. Email info@mvrktabz.com. Adults 21+.',
			'giveaway'        => 'Win 100 free MVRK tablets every month. Buy MVRK, email your proof of purchase, and a new winner is drawn on video monthly. 21+.',
			'winners'         => 'MVRK monthly giveaway winners — every draw posted on video. For adults 21+.',
			'official-rules'  => 'Official Rules for the MVRK monthly giveaway. 21+, US residents in eligible states, void where prohibited.',
			'privacy'         => 'MVRK privacy policy — how we collect, use, and protect your information.',
			'terms'           => 'MVRK terms of service.',
		);
		if ( isset( $post->post_name ) && isset( $map[ $post->post_name ] ) ) {
			return $map[ $post->post_name ];
		}

		$excerpt = trim( wp_strip_all_tags( get_the_excerpt( $post ) ) );
		if ( $excerpt ) {
			return wp_trim_words( $excerpt, 30 );
		}
	}

	return $brand;
}

/**
 * Best Open Graph image for the current view.
 */
function mvrk_seo_image() {
	if ( is_singular() && has_post_thumbnail() ) {
		$src = wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' );
		if ( $src ) {
			return $src;
		}
	}
	// Brand fallback (also used until a dedicated 1200×630 OG image is supplied).
	return MVRK_URI . '/assets/img/giveaway-flyer.jpg';
}

/**
 * Output all SEO meta + JSON-LD in <head>.
 */
function mvrk_seo_meta() {
	$title = wp_get_document_title();
	$desc  = trim( mvrk_seo_description() );
	$image = mvrk_seo_image();
	$url   = '';
	if ( is_singular() ) {
		$url = get_permalink();
	} elseif ( function_exists( 'is_shop' ) && is_shop() ) {
		$url = get_permalink( wc_get_page_id( 'shop' ) );
	} else {
		global $wp;
		$url = home_url( add_query_arg( array(), $wp->request ) );
	}
	$type = ( function_exists( 'is_product' ) && is_product() ) ? 'product' : ( is_front_page() ? 'website' : 'article' );

	echo "\n<!-- MVRK SEO -->\n";
	printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $desc ) );
	// WordPress core (rel_canonical) already adds the canonical on singular pages;
	// only add ours where core doesn't (front/shop/archives).
	if ( ! is_singular() ) {
		printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );
	}

	// Open Graph.
	printf( '<meta property="og:type" content="%s" />' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:site_name" content="%s" />' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $desc ) );
	printf( '<meta property="og:url" content="%s" />' . "\n", esc_url( $url ) );
	printf( '<meta property="og:image" content="%s" />' . "\n", esc_url( $image ) );
	echo '<meta property="og:locale" content="en_US" />' . "\n";

	// Twitter.
	echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
	printf( '<meta name="twitter:title" content="%s" />' . "\n", esc_attr( $title ) );
	printf( '<meta name="twitter:description" content="%s" />' . "\n", esc_attr( $desc ) );
	printf( '<meta name="twitter:image" content="%s" />' . "\n", esc_url( $image ) );

	// Organization JSON-LD (site-wide).
	$org = array(
		'@context' => 'https://schema.org',
		'@type'    => 'Organization',
		'name'     => mvrk_get( 'business.legal_name', 'MVRK' ),
		'url'      => home_url( '/' ),
		'email'    => mvrk_get( 'business.email', 'info@mvrktabz.com' ),
		'slogan'   => mvrk_get( 'business.tagline', 'Think Like a Maverick.' ),
		'logo'     => MVRK_URI . '/assets/img/mvrk-logo.png',
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $org ) . '</script>' . "\n";
	// Note: WooCommerce already outputs Product JSON-LD on product pages — we don't duplicate it.
	echo "<!-- /MVRK SEO -->\n";
}
add_action( 'wp_head', 'mvrk_seo_meta', 5 );
