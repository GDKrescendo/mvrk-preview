<?php
/**
 * Theme contact form handler (admin-post). Honeypot + nonce + wp_mail.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mvrk_handle_contact() {
	$redirect = wp_get_referer() ? wp_get_referer() : home_url( '/contact/' );

	if ( ! isset( $_POST['mvrk_contact_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['mvrk_contact_nonce'] ), 'mvrk_contact' ) ) {
		wp_safe_redirect( add_query_arg( 'sent', 'error', $redirect ) );
		exit;
	}
	// Honeypot.
	if ( ! empty( $_POST['company'] ) ) {
		wp_safe_redirect( add_query_arg( 'sent', 'ok', $redirect ) );
		exit;
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( strlen( $name ) < 2 || ! is_email( $email ) || strlen( $message ) < 5 ) {
		wp_safe_redirect( add_query_arg( 'sent', 'error', $redirect ) );
		exit;
	}

	$to      = mvrk_get( 'business.email', get_option( 'admin_email' ) );
	$subject = sprintf( '[MVRK] Contact form — %s', $name );
	$body    = "Name: {$name}\nEmail: {$email}\nPhone: {$phone}\n\n{$message}";
	$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );
	wp_mail( $to, $subject, $body, $headers );

	wp_safe_redirect( add_query_arg( 'sent', 'ok', $redirect ) );
	exit;
}
add_action( 'admin_post_nopriv_mvrk_contact', 'mvrk_handle_contact' );
add_action( 'admin_post_mvrk_contact', 'mvrk_handle_contact' );
