<?php
/**
 * Footer.
 *
 * @package MVRK
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$biz     = mvrk_get( 'business' );
$d       = mvrk_get( 'disclaimer' );
$socials = mvrk_social_links();
$logo    = MVRK_URI . '/assets/img/mvrk-logo.png';
$shop    = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop/' );

$foot_nav = array(
	array( 'Shop', $shop ),
	array( 'Win Free MVRK', home_url( '/giveaway/' ) ),
	array( 'Winners', home_url( '/winners/' ) ),
	array( 'Our Story', home_url( '/story/' ) ),
	array( 'Responsible Use', home_url( '/responsible-use/' ) ),
	array( 'Contact', home_url( '/contact/' ) ),
);
?>
<footer class="footer">
	<div class="container-mvrk">
		<div class="footer__top">
			<div class="footer__brand">
				<img src="<?php echo esc_url( $logo ); ?>" alt="MVRK" width="132" height="44" loading="lazy" />
				<p class="footer__tag"><?php echo esc_html( $biz['tagline'] . ' ' . $biz['sub_tagline'] ); ?></p>
				<?php if ( $socials ) : ?>
					<div class="footer__social">
						<?php foreach ( $socials as $s ) : ?>
							<a href="<?php echo esc_url( $s['href'] ); ?>" aria-label="<?php echo esc_attr( $s['label'] ); ?>" class="footer__social-link" rel="noopener" target="_blank"><?php mvrk_icon( $s['icon'] ); ?></a>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>

			<nav class="footer__col" aria-label="<?php esc_attr_e( 'Footer', 'mvrk' ); ?>">
				<h3 class="footer__heading"><?php esc_html_e( 'Explore', 'mvrk' ); ?></h3>
				<?php foreach ( $foot_nav as $item ) : ?>
					<a href="<?php echo esc_url( $item[1] ); ?>" class="footer__link"><?php echo esc_html( $item[0] ); ?></a>
				<?php endforeach; ?>
			</nav>

			<div class="footer__col">
				<h3 class="footer__heading"><?php esc_html_e( 'Contact', 'mvrk' ); ?></h3>
				<a href="mailto:<?php echo esc_attr( $biz['email'] ); ?>" class="footer__link footer__contact"><?php mvrk_icon( 'mail', 'ico-sm' ); ?> <?php echo esc_html( $biz['email'] ); ?></a>
				<?php if ( ! empty( $biz['phone'] ) ) : ?>
					<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $biz['phone'] ) ); ?>" class="footer__link footer__contact"><?php mvrk_icon( 'phone', 'ico-sm' ); ?> <?php echo esc_html( $biz['phone'] ); ?></a>
				<?php endif; ?>
				<p class="footer__link footer__contact"><?php mvrk_icon( 'map-pin', 'ico-sm' ); ?> <?php echo esc_html( $biz['country'] ); ?></p>
				<?php if ( ! empty( $biz['hours'] ) ) : ?>
					<p class="footer__link footer__contact"><?php mvrk_icon( 'clock', 'ico-sm' ); ?> <?php echo esc_html( $biz['hours'] ); ?></p>
				<?php endif; ?>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>" class="footer__link footer__pill"><?php mvrk_icon( 'shield-check', 'ico-sm' ); ?> <?php esc_html_e( 'Responsible Use & 21+', 'mvrk' ); ?></a>
			</div>
		</div>

		<div class="footer__legal">
			<p><?php echo esc_html( $d['fda'] ); ?></p>
			<p><?php echo esc_html( $d['dependence'] ); ?></p>
		</div>

		<div class="footer__bottom">
			<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( $biz['legal_name'] ); ?>. <?php esc_html_e( 'All rights reserved.', 'mvrk' ); ?></p>
			<nav class="footer__bottom-links" aria-label="<?php esc_attr_e( 'Legal', 'mvrk' ); ?>">
				<a href="<?php echo esc_url( home_url( '/official-rules/' ) ); ?>"><?php esc_html_e( 'Official Rules', 'mvrk' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/privacy/' ) ); ?>"><?php esc_html_e( 'Privacy', 'mvrk' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms', 'mvrk' ); ?></a>
				<a href="<?php echo esc_url( home_url( '/responsible-use/' ) ); ?>"><?php esc_html_e( 'Responsible Use', 'mvrk' ); ?></a>
			</nav>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
