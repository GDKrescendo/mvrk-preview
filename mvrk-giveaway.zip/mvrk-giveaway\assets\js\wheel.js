/* MVRK giveaway wheel — canvas, eased spin. The on-page wheel is a visual of
   this month's entrants; the official winner is drawn by the owner on video. */
(function () {
  "use strict";

  var cfg = window.MVRK_GA || {};
  var root = document.querySelector("[data-mvrk-wheel]");
  if (!root || !cfg.restUrl) return;

  var canvas = root.querySelector(".mvrk-wheel__canvas");
  var ctx = canvas.getContext("2d");
  var spinBtn = root.querySelector("[data-mvrk-spin]");
  var resultEl = root.querySelector("[data-mvrk-result]");
  var emptyEl = root.querySelector(".mvrk-wheel__empty");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var names = [];
  var angle = 0; // current rotation (radians)
  var spinning = false;

  // Warm brand palette (alternating).
  var colors = [
    "#3a1418", "#7a1f25", "#2a1a12", "#5e1a20",
    "#241a14", "#6b1d23", "#321217", "#822127",
  ];

  function size() {
    var s = Math.min(root.clientWidth || 520, 520);
    var dpr = window.devicePixelRatio || 1;
    canvas.width = s * dpr;
    canvas.height = s * dpr;
    canvas.style.width = s + "px";
    canvas.style.height = s + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    draw();
  }

  function draw() {
    var s = canvas.width / (window.devicePixelRatio || 1);
    var r = s / 2;
    ctx.clearRect(0, 0, s, s);
    if (!names.length) return;

    var seg = (Math.PI * 2) / names.length;
    ctx.save();
    ctx.translate(r, r);
    ctx.rotate(angle);

    for (var i = 0; i < names.length; i++) {
      var start = i * seg;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, r - 6, start, start + seg);
      ctx.closePath();
      ctx.fillStyle = colors[i % colors.length];
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.06)";
      ctx.lineWidth = 1;
      ctx.stroke();

      // Label.
      ctx.save();
      ctx.rotate(start + seg / 2);
      ctx.textAlign = "right";
      ctx.fillStyle = "#f4ece6";
      var fs = Math.max(10, Math.min(18, 320 / names.length + 8));
      ctx.font = "600 " + fs + "px 'Hanken Grotesk', system-ui, sans-serif";
      var label = names[i].length > 16 ? names[i].slice(0, 15) + "…" : names[i];
      ctx.fillText(label, r - 22, fs / 3);
      ctx.restore();
    }
    ctx.restore();

    // Rim.
    ctx.beginPath();
    ctx.arc(r, r, r - 5, 0, Math.PI * 2);
    ctx.strokeStyle = "#e0473a";
    ctx.lineWidth = 4;
    ctx.stroke();
  }

  function easeOutQuint(t) {
    return 1 - Math.pow(1 - t, 5);
  }

  function spin() {
    if (spinning || !names.length) return;
    spinning = true;
    resultEl.textContent = "";
    spinBtn.disabled = true;

    var seg = (Math.PI * 2) / names.length;
    var winner = Math.floor(Math.random() * names.length);
    // Pointer is at top (-90deg). Land the winner segment center under it.
    var target =
      Math.PI * 2 * (reduce ? 2 : 6) +
      (-Math.PI / 2 - (winner * seg + seg / 2));
    var startAngle = angle % (Math.PI * 2);
    var delta = target - startAngle;
    var dur = reduce ? 200 : 4200;
    var t0 = null;

    function frame(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / dur, 1);
      angle = startAngle + delta * easeOutQuint(p);
      draw();
      if (p < 1) {
        requestAnimationFrame(frame);
      } else {
        spinning = false;
        spinBtn.disabled = false;
        resultEl.textContent = "🎉 " + names[winner] + " — a sample spin. The real winner is drawn by the owner on video.";
      }
    }
    requestAnimationFrame(frame);
  }

  function load() {
    var url = cfg.restUrl + (cfg.month ? "?month=" + encodeURIComponent(cfg.month) : "");
    fetch(url, { headers: { "X-WP-Nonce": cfg.nonce || "" } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        names = (data && data.names) || [];
        if (!names.length) {
          if (emptyEl) emptyEl.hidden = false;
          if (spinBtn) spinBtn.disabled = true;
          canvas.style.opacity = "0.35";
        } else {
          if (emptyEl) emptyEl.hidden = true;
          if (spinBtn) spinBtn.disabled = false;
          canvas.style.opacity = "1";
        }
        size();
      })
      .catch(function () {
        if (emptyEl) { emptyEl.hidden = false; emptyEl.textContent = "Couldn't load entrants right now."; }
      });
  }

  if (spinBtn) spinBtn.addEventListener("click", spin);
  window.addEventListener("resize", size, { passive: true });
  load();
})();
