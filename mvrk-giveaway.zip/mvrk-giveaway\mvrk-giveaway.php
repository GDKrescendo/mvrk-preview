<?php
/**
 * Plugin Name:       MVRK Giveaway
 * Plugin URI:        https://mvrktabz.com
 * Description:        Monthly receipt-to-win giveaway for MVRK — receipt + free (AMOE) entry forms, owner approval, a live name wheel, and a monthly winner video archive. Adults 21+. Includes a "no purchase necessary" path; have Official Rules reviewed by counsel before launch.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Krescendo AI (Godfrey Diaz)
 * Author URI:        https://krescendoai.com
 * License:           GPL-2.0-or-later
 * Text Domain:       mvrk-giveaway
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MVRK_GA_VERSION', '1.0.0' );
define( 'MVRK_GA_FILE', __FILE__ );
define( 'MVRK_GA_DIR', plugin_dir_path( __FILE__ ) );
define( 'MVRK_GA_URI', plugin_dir_url( __FILE__ ) );
define( 'MVRK_GA_TABLE', 'mvrk_entries' );

require_once MVRK_GA_DIR . 'includes/db.php';
require_once MVRK_GA_DIR . 'includes/helpers.php';
require_once MVRK_GA_DIR . 'includes/submission.php';
require_once MVRK_GA_DIR . 'includes/wheel.php';
require_once MVRK_GA_DIR . 'includes/winners.php';
require_once MVRK_GA_DIR . 'includes/admin.php';

/**
 * Activation: create the entries table + the giveaway/winners pages, flush rewrites.
 */
function mvrk_ga_activate() {
	// Keep activation minimal & fast (robust). Heavier setup runs once on init.
	mvrk_ga_create_table();
	update_option( 'mvrk_ga_needs_setup', 'yes' );
}
register_activation_hook( __FILE__, 'mvrk_ga_activate' );

/**
 * Idempotent install/setup — self-heals even if the activation hook was skipped.
 * Creates the table + giveaway/winners pages, then flushes rewrites once.
 */
function mvrk_ga_maybe_setup() {
	if ( 'yes' !== get_option( 'mvrk_ga_needs_setup' ) && get_option( 'mvrk_ga_db_ready' ) ) {
		return;
	}
	mvrk_ga_create_table();
	mvrk_ga_ensure_pages();
	flush_rewrite_rules();
	update_option( 'mvrk_ga_db_ready', '1' );
	delete_option( 'mvrk_ga_needs_setup' );
}
add_action( 'init', 'mvrk_ga_maybe_setup', 20 );

/**
 * Deactivation: flush rewrites (keep data).
 */
function mvrk_ga_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'mvrk_ga_deactivate' );

/**
 * Ensure the Giveaway + Winners pages exist (idempotent).
 */
function mvrk_ga_ensure_pages() {
	$pages = array(
		'giveaway' => array(
			'title'   => 'Win Free MVRK',
			'content' => "<!-- wp:shortcode -->[mvrk_giveaway]<!-- /wp:shortcode -->",
		),
		'winners'  => array(
			'title'   => 'Winners',
			'content' => "<!-- wp:shortcode -->[mvrk_winners]<!-- /wp:shortcode -->",
		),
	);
	foreach ( $pages as $slug => $data ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post( array(
				'post_title'   => $data['title'],
				'post_name'    => $slug,
				'post_content' => $data['content'],
				'post_status'  => 'publish',
				'post_type'    => 'page',
			) );
		}
	}
}

/**
 * Register the Winners CPT early.
 */
add_action( 'init', 'mvrk_ga_register_winner_cpt' );

/**
 * Front-end assets (only where our shortcodes are used).
 */
function mvrk_ga_assets() {
	if ( ! is_singular() && ! is_post_type_archive( 'mvrk_winner' ) ) {
		// still allow on pages that embed shortcodes; load broadly but lightly.
	}
	wp_register_style( 'mvrk-ga', MVRK_GA_URI . 'assets/css/giveaway.css', array(), MVRK_GA_VERSION );
	wp_register_script( 'mvrk-ga-wheel', MVRK_GA_URI . 'assets/js/wheel.js', array(), MVRK_GA_VERSION, true );
	wp_localize_script( 'mvrk-ga-wheel', 'MVRK_GA', array(
		'restUrl' => esc_url_raw( rest_url( 'mvrk/v1/entrants' ) ),
		'month'   => gmdate( 'Y-m' ),
		'nonce'   => wp_create_nonce( 'wp_rest' ),
	) );
}
add_action( 'wp_enqueue_scripts', 'mvrk_ga_assets' );
