<?php
/**
 * Admin — Giveaway entries review + approval, prize setting.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Top-level admin menu + subpages. (Winners CPT attaches here via show_in_menu.)
 */
function mvrk_ga_admin_menu() {
	add_menu_page(
		__( 'MVRK Giveaway', 'mvrk-giveaway' ),
		__( 'MVRK Giveaway', 'mvrk-giveaway' ),
		'manage_options',
		'mvrk-giveaway',
		'mvrk_ga_entries_page',
		'dashicons-tickets-alt',
		26
	);
	add_submenu_page( 'mvrk-giveaway', __( 'Entries', 'mvrk-giveaway' ), __( 'Entries', 'mvrk-giveaway' ), 'manage_options', 'mvrk-giveaway', 'mvrk_ga_entries_page' );
	add_submenu_page( 'mvrk-giveaway', __( 'Settings', 'mvrk-giveaway' ), __( 'Settings', 'mvrk-giveaway' ), 'manage_options', 'mvrk-giveaway-settings', 'mvrk_ga_settings_page' );
}
add_action( 'admin_menu', 'mvrk_ga_admin_menu' );

/**
 * Register the prize setting.
 */
function mvrk_ga_register_settings() {
	register_setting( 'mvrk_ga_settings', 'mvrk_ga_prize', array( 'sanitize_callback' => 'sanitize_text_field' ) );
}
add_action( 'admin_init', 'mvrk_ga_register_settings' );

/**
 * Handle approve/reject actions.
 */
function mvrk_ga_handle_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'mvrk-giveaway' ) );
	}
	$id     = isset( $_GET['entry'] ) ? (int) $_GET['entry'] : 0;
	$action = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
	check_admin_referer( 'mvrk_ga_action_' . $id );

	$map = array( 'approve' => 'approved', 'reject' => 'rejected', 'pending' => 'pending' );
	if ( $id && isset( $map[ $action ] ) ) {
		mvrk_ga_set_status( $id, $map[ $action ] );
	}
	wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=mvrk-giveaway' ) );
	exit;
}
add_action( 'admin_post_mvrk_ga_action', 'mvrk_ga_handle_action' );

/**
 * Manually add an entrant (e.g. from a giveaway email). Adds them approved
 * for the given month so they appear on the wheel right away.
 */
function mvrk_ga_handle_add_entrant() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'mvrk-giveaway' ) );
	}
	check_admin_referer( 'mvrk_ga_add_entrant' );

	$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$month = isset( $_POST['month'] ) ? sanitize_text_field( wp_unslash( $_POST['month'] ) ) : mvrk_ga_month();
	if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
		$month = mvrk_ga_month();
	}

	$redirect = admin_url( 'admin.php?page=mvrk-giveaway&m=' . rawurlencode( $month ) );
	if ( strlen( $name ) >= 2 ) {
		mvrk_ga_insert_entry( array(
			'name'       => $name,
			'email'      => $email,
			'entry_type' => 'email',
			'month'      => $month,
			'status'     => 'approved',
		) );
		$redirect = add_query_arg( 'added', '1', $redirect );
	}
	wp_safe_redirect( $redirect );
	exit;
}
add_action( 'admin_post_mvrk_ga_add_entrant', 'mvrk_ga_handle_add_entrant' );

/**
 * Entries review screen.
 */
function mvrk_ga_entries_page() {
	$month  = isset( $_GET['m'] ) ? sanitize_text_field( wp_unslash( $_GET['m'] ) ) : mvrk_ga_month(); // phpcs:ignore WordPress.Security.NonceVerification
	$status = isset( $_GET['s'] ) ? sanitize_key( $_GET['s'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
		$month = mvrk_ga_month();
	}
	$entries = mvrk_ga_get_entries( array( 'month' => $month, 'status' => $status, 'limit' => 500 ) );
	$counts  = array(
		'all'      => mvrk_ga_count( $month, '' ),
		'pending'  => mvrk_ga_count( $month, 'pending' ),
		'approved' => mvrk_ga_count( $month, 'approved' ),
		'rejected' => mvrk_ga_count( $month, 'rejected' ),
	);
	$base = admin_url( 'admin.php?page=mvrk-giveaway&m=' . rawurlencode( $month ) );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'MVRK Giveaway — Entries', 'mvrk-giveaway' ); ?></h1>

		<form method="get" style="margin:1em 0">
			<input type="hidden" name="page" value="mvrk-giveaway" />
			<label><?php esc_html_e( 'Month', 'mvrk-giveaway' ); ?>
				<input type="text" name="m" value="<?php echo esc_attr( $month ); ?>" placeholder="YYYY-MM" />
			</label>
			<button class="button"><?php esc_html_e( 'View', 'mvrk-giveaway' ); ?></button>
		</form>

		<div class="mvrk-ga-add" style="margin:1em 0 1.5em;padding:1em 1.25em;background:#fff;border:1px solid #dcdcde;border-radius:6px;max-width:680px">
			<strong><?php esc_html_e( 'Add an entrant from an email', 'mvrk-giveaway' ); ?></strong>
			<p class="description" style="margin:.25em 0 .75em"><?php esc_html_e( 'Verified a proof-of-purchase email? Add the entrant here and they go straight onto this month\'s wheel.', 'mvrk-giveaway' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:.5em;flex-wrap:wrap;align-items:center">
				<input type="hidden" name="action" value="mvrk_ga_add_entrant" />
				<input type="hidden" name="month" value="<?php echo esc_attr( $month ); ?>" />
				<?php wp_nonce_field( 'mvrk_ga_add_entrant' ); ?>
				<input type="text" name="name" placeholder="<?php esc_attr_e( 'Full name', 'mvrk-giveaway' ); ?>" required style="min-width:180px" />
				<input type="email" name="email" placeholder="<?php esc_attr_e( 'Email (optional)', 'mvrk-giveaway' ); ?>" style="min-width:200px" />
				<button class="button button-primary"><?php esc_html_e( 'Add to wheel', 'mvrk-giveaway' ); ?></button>
			</form>
		</div>

		<?php if ( isset( $_GET['added'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Entrant added to the wheel.', 'mvrk-giveaway' ); ?></p></div>
		<?php endif; ?>

		<ul class="subsubsub">
			<li><a href="<?php echo esc_url( $base ); ?>" class="<?php echo '' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'All', 'mvrk-giveaway' ); ?> <span class="count">(<?php echo (int) $counts['all']; ?>)</span></a> | </li>
			<li><a href="<?php echo esc_url( $base . '&s=pending' ); ?>" class="<?php echo 'pending' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'Pending', 'mvrk-giveaway' ); ?> <span class="count">(<?php echo (int) $counts['pending']; ?>)</span></a> | </li>
			<li><a href="<?php echo esc_url( $base . '&s=approved' ); ?>" class="<?php echo 'approved' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'Approved', 'mvrk-giveaway' ); ?> <span class="count">(<?php echo (int) $counts['approved']; ?>)</span></a> | </li>
			<li><a href="<?php echo esc_url( $base . '&s=rejected' ); ?>" class="<?php echo 'rejected' === $status ? 'current' : ''; ?>"><?php esc_html_e( 'Rejected', 'mvrk-giveaway' ); ?> <span class="count">(<?php echo (int) $counts['rejected']; ?>)</span></a></li>
		</ul>

		<table class="wp-list-table widefat fixed striped">
			<thead><tr>
				<th><?php esc_html_e( 'Name', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Email', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Type', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Receipt', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Status', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Submitted', 'mvrk-giveaway' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'mvrk-giveaway' ); ?></th>
			</tr></thead>
			<tbody>
			<?php if ( $entries ) : ?>
				<?php foreach ( $entries as $e ) :
					$nonce = wp_create_nonce( 'mvrk_ga_action_' . $e->id );
					$act   = admin_url( 'admin-post.php?action=mvrk_ga_action&entry=' . $e->id . '&_wpnonce=' . $nonce );
					?>
					<tr>
						<td><strong><?php echo esc_html( $e->name ); ?></strong><?php echo $e->phone ? '<br><small>' . esc_html( $e->phone ) . '</small>' : ''; ?></td>
						<td><?php echo esc_html( $e->email ); ?></td>
						<td><?php
						$type_labels = array( 'email' => __( 'Email', 'mvrk-giveaway' ), 'amoe' => __( 'Free (AMOE)', 'mvrk-giveaway' ), 'purchase' => __( 'Purchase', 'mvrk-giveaway' ) );
						echo esc_html( isset( $type_labels[ $e->entry_type ] ) ? $type_labels[ $e->entry_type ] : ucfirst( $e->entry_type ) );
					?></td>
						<td><?php echo $e->receipt_url ? '<a href="' . esc_url( $e->receipt_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'View', 'mvrk-giveaway' ) . '</a>' : '&mdash;'; ?></td>
						<td><span class="mvrk-ga-status mvrk-ga-status--<?php echo esc_attr( $e->status ); ?>"><?php echo esc_html( ucfirst( $e->status ) ); ?></span></td>
						<td><?php echo esc_html( mysql2date( 'M j, Y', $e->created_at ) ); ?></td>
						<td>
							<?php if ( 'approved' !== $e->status ) : ?>
								<a class="button button-primary button-small" href="<?php echo esc_url( $act . '&do=approve' ); ?>"><?php esc_html_e( 'Approve', 'mvrk-giveaway' ); ?></a>
							<?php endif; ?>
							<?php if ( 'rejected' !== $e->status ) : ?>
								<a class="button button-small" href="<?php echo esc_url( $act . '&do=reject' ); ?>"><?php esc_html_e( 'Reject', 'mvrk-giveaway' ); ?></a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php else : ?>
				<tr><td colspan="7"><?php esc_html_e( 'No entries for this filter.', 'mvrk-giveaway' ); ?></td></tr>
			<?php endif; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Approved entries for the selected month appear on the public wheel. Verify each receipt before approving.', 'mvrk-giveaway' ); ?></p>
	</div>
	<?php
}

/**
 * Settings screen (monthly prize text).
 */
function mvrk_ga_settings_page() {
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'MVRK Giveaway — Settings', 'mvrk-giveaway' ); ?></h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'mvrk_ga_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="mvrk_ga_prize"><?php esc_html_e( 'This month\'s prize', 'mvrk-giveaway' ); ?></label></th>
					<td>
						<input type="text" id="mvrk_ga_prize" name="mvrk_ga_prize" value="<?php echo esc_attr( mvrk_ga_prize() ); ?>" class="large-text" />
						<p class="description"><?php esc_html_e( 'Shown on the giveaway page, e.g. "One free jar of MVRK (winner\'s choice)".', 'mvrk-giveaway' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<hr>
		<h2><?php esc_html_e( 'Posting a monthly winner', 'mvrk-giveaway' ); ?></h2>
		<p><?php esc_html_e( 'When you draw a winner on video, go to Giveaway Winners → Add Monthly Winner, set the month, the winner\'s name, and paste your (unlisted) YouTube/Vimeo link or an uploaded MP4 URL. It appears on the Winners page automatically.', 'mvrk-giveaway' ); ?></p>
	</div>
	<?php
}

/**
 * Tiny admin styling for status pills.
 */
function mvrk_ga_admin_css() {
	$screen = get_current_screen();
	if ( ! $screen || false === strpos( (string) $screen->id, 'mvrk-giveaway' ) ) {
		return;
	}
	echo '<style>.mvrk-ga-status{padding:2px 8px;border-radius:99px;font-size:11px;font-weight:600}.mvrk-ga-status--approved{background:#d8f5e3;color:#0a6b35}.mvrk-ga-status--pending{background:#fdf0d5;color:#8a5a00}.mvrk-ga-status--rejected{background:#f6d8d8;color:#8a1f1f}</style>';
}
add_action( 'admin_head', 'mvrk_ga_admin_css' );
