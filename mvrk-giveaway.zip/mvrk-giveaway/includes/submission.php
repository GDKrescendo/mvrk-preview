<?php
/**
 * Giveaway entry form + submission handling + the [mvrk_giveaway] page shortcode.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const MVRK_GA_MAX_UPLOAD = 10485760; // 10 MB.

/**
 * Allowed receipt mime types.
 */
function mvrk_ga_allowed_mimes() {
	return array(
		'jpg|jpeg' => 'image/jpeg',
		'png'      => 'image/png',
		'webp'     => 'image/webp',
		'heic'     => 'image/heic',
		'pdf'      => 'application/pdf',
	);
}

/**
 * Handle a giveaway entry submission.
 */
function mvrk_ga_handle_submit() {
	$redirect = wp_get_referer() ? wp_get_referer() : home_url( '/giveaway/' );

	// Nonce.
	if ( ! isset( $_POST['mvrk_ga_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['mvrk_ga_nonce'] ), 'mvrk_ga_submit' ) ) {
		wp_safe_redirect( add_query_arg( 'mvrk_ga', 'error', $redirect ) );
		exit;
	}

	// Honeypot — bots fill this hidden field.
	if ( ! empty( $_POST['company'] ) ) {
		wp_safe_redirect( add_query_arg( 'mvrk_ga', 'success', $redirect ) ); // silently "succeed".
		exit;
	}

	$entry_type = 'purchase'; // Receipt-only giveaway — a valid receipt is required to enter.
	$name       = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email      = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone      = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$order_no   = isset( $_POST['order_no'] ) ? sanitize_text_field( wp_unslash( $_POST['order_no'] ) ) : '';
	$age_ok     = ! empty( $_POST['age_confirm'] );
	$rules_ok   = ! empty( $_POST['rules_agree'] );

	$errors = array();
	if ( strlen( $name ) < 2 ) {
		$errors[] = 'name';
	}
	if ( ! is_email( $email ) ) {
		$errors[] = 'email';
	}
	if ( ! $age_ok ) {
		$errors[] = 'age';
	}
	if ( ! $rules_ok ) {
		$errors[] = 'rules';
	}

	$month = mvrk_ga_month();

	// One entry per email per month.
	if ( empty( $errors ) && mvrk_ga_already_entered( $email, $month ) ) {
		wp_safe_redirect( add_query_arg( 'mvrk_ga', 'dupe', $redirect ) );
		exit;
	}

	// A valid receipt upload is always required.
	$receipt_url = '';
	if ( empty( $_FILES['receipt']['name'] ) ) {
		$errors[] = 'receipt';
	} else {
		$file = $_FILES['receipt']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( $file['size'] > MVRK_GA_MAX_UPLOAD ) {
			$errors[] = 'receipt_size';
		} else {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			add_filter( 'upload_dir', 'mvrk_ga_receipt_dir' );
			$moved = wp_handle_upload( $file, array(
				'test_form' => false,
				'mimes'     => mvrk_ga_allowed_mimes(),
			) );
			remove_filter( 'upload_dir', 'mvrk_ga_receipt_dir' );
			if ( isset( $moved['url'] ) ) {
				$receipt_url = esc_url_raw( $moved['url'] );
			} else {
				$errors[] = 'receipt_type';
			}
		}
	}

	if ( ! empty( $errors ) ) {
		wp_safe_redirect( add_query_arg( array( 'mvrk_ga' => 'error', 'fields' => implode( ',', $errors ) ), $redirect ) );
		exit;
	}

	$id = mvrk_ga_insert_entry( array(
		'name'        => $name,
		'email'       => $email,
		'phone'       => $phone,
		'order_no'    => $order_no,
		'receipt_url' => $receipt_url,
		'entry_type'  => $entry_type,
		'month'       => $month,
		'status'      => 'pending',
		'ip'          => mvrk_ga_client_ip(),
	) );

	if ( is_wp_error( $id ) ) {
		wp_safe_redirect( add_query_arg( 'mvrk_ga', 'error', $redirect ) );
		exit;
	}

	// Notify the owner.
	mvrk_ga_notify_admin( $id, $name, $entry_type );

	wp_safe_redirect( add_query_arg( 'mvrk_ga', 'success', $redirect ) );
	exit;
}
add_action( 'admin_post_nopriv_mvrk_ga_submit', 'mvrk_ga_handle_submit' );
add_action( 'admin_post_mvrk_ga_submit', 'mvrk_ga_handle_submit' );

/**
 * Store receipts in /uploads/mvrk-receipts.
 */
function mvrk_ga_receipt_dir( $dirs ) {
	$dirs['subdir'] = '/mvrk-receipts';
	$dirs['path']   = $dirs['basedir'] . $dirs['subdir'];
	$dirs['url']    = $dirs['baseurl'] . $dirs['subdir'];
	return $dirs;
}

/**
 * Best-effort client IP.
 */
function mvrk_ga_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return substr( $ip, 0, 64 );
}

/**
 * Email the site admin about a new pending entry.
 */
function mvrk_ga_notify_admin( $id, $name, $type ) {
	$to      = get_option( 'admin_email' );
	$subject = sprintf( '[MVRK Giveaway] New %s entry pending review', $type );
	$link    = admin_url( 'admin.php?page=mvrk-giveaway' );
	$body    = sprintf( "A new giveaway entry (#%d) from %s is awaiting approval.\n\nReview: %s", $id, $name, $link );
	wp_mail( $to, $subject, $body );
}

/**
 * Render the entry form.
 */
function mvrk_ga_render_form() {
	wp_enqueue_style( 'mvrk-ga' );
	$status = isset( $_GET['mvrk_ga'] ) ? sanitize_key( $_GET['mvrk_ga'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$fields = isset( $_GET['fields'] ) ? array_map( 'sanitize_key', explode( ',', wp_unslash( $_GET['fields'] ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
	ob_start();
	?>
	<div class="mvrk-ga-form-wrap" id="enter">
		<?php if ( 'success' === $status ) : ?>
			<div class="mvrk-ga-alert mvrk-ga-alert--ok"><?php mvrk_ga_icon( 'check-circle' ); ?> <span><?php esc_html_e( 'You\'re in! Once we verify your entry, your name joins this month\'s wheel. Watch the Winners page for the monthly draw video.', 'mvrk-giveaway' ); ?></span></div>
		<?php elseif ( 'dupe' === $status ) : ?>
			<div class="mvrk-ga-alert mvrk-ga-alert--warn"><span><?php esc_html_e( 'You\'ve already entered this month — one entry per person, per month. Good luck!', 'mvrk-giveaway' ); ?></span></div>
		<?php elseif ( 'error' === $status ) : ?>
			<div class="mvrk-ga-alert mvrk-ga-alert--err"><span><?php esc_html_e( 'Something needs fixing below. Please check the highlighted fields and resubmit.', 'mvrk-giveaway' ); ?></span></div>
		<?php endif; ?>

		<form class="mvrk-ga-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate>
			<input type="hidden" name="action" value="mvrk_ga_submit" />
			<?php wp_nonce_field( 'mvrk_ga_submit', 'mvrk_ga_nonce' ); ?>

			<div class="mvrk-ga-field">
				<label for="ga-name"><?php esc_html_e( 'Name', 'mvrk-giveaway' ); ?></label>
				<input id="ga-name" name="name" type="text" autocomplete="name" required<?php echo in_array( 'name', $fields, true ) ? ' aria-invalid="true"' : ''; ?> />
			</div>
			<div class="mvrk-ga-field">
				<label for="ga-email"><?php esc_html_e( 'Email', 'mvrk-giveaway' ); ?></label>
				<input id="ga-email" name="email" type="email" autocomplete="email" required<?php echo in_array( 'email', $fields, true ) ? ' aria-invalid="true"' : ''; ?> />
			</div>
			<div class="mvrk-ga-field">
				<label for="ga-phone"><?php esc_html_e( 'Phone', 'mvrk-giveaway' ); ?> <span class="opt"><?php esc_html_e( '(optional)', 'mvrk-giveaway' ); ?></span></label>
				<input id="ga-phone" name="phone" type="tel" autocomplete="tel" />
			</div>

			<div class="mvrk-ga-field">
				<label for="ga-order"><?php esc_html_e( 'Order number', 'mvrk-giveaway' ); ?> <span class="opt"><?php esc_html_e( '(if you have it)', 'mvrk-giveaway' ); ?></span></label>
				<input id="ga-order" name="order_no" type="text" />
			</div>
			<div class="mvrk-ga-field">
				<label for="ga-receipt"><?php esc_html_e( 'Upload your receipt', 'mvrk-giveaway' ); ?></label>
				<input id="ga-receipt" name="receipt" type="file" accept=".jpg,.jpeg,.png,.webp,.heic,.pdf" required<?php echo in_array( 'receipt', $fields, true ) ? ' aria-invalid="true"' : ''; ?> />
				<p class="mvrk-ga-hint"><?php esc_html_e( 'JPG, PNG, WEBP, or PDF · up to 10MB. A valid receipt is required to enter. We verify every receipt before it joins the wheel.', 'mvrk-giveaway' ); ?></p>
			</div>

			<label class="mvrk-ga-check">
				<input type="checkbox" name="age_confirm" value="1" required<?php echo in_array( 'age', $fields, true ) ? ' aria-invalid="true"' : ''; ?> />
				<span><?php esc_html_e( 'I confirm I am 21 years of age or older and a US resident in an eligible state.', 'mvrk-giveaway' ); ?></span>
			</label>
			<label class="mvrk-ga-check">
				<input type="checkbox" name="rules_agree" value="1" required<?php echo in_array( 'rules', $fields, true ) ? ' aria-invalid="true"' : ''; ?> />
				<span><?php printf( /* translators: %s: rules URL */ esc_html__( 'I have read and agree to the %s.', 'mvrk-giveaway' ), '<a href="' . esc_url( mvrk_ga_rules_url() ) . '" target="_blank" rel="noopener">' . esc_html__( 'Official Rules', 'mvrk-giveaway' ) . '</a>' ); ?></span>
			</label>

			<div class="mvrk-ga-hp" aria-hidden="true">
				<label for="ga-company"><?php esc_html_e( 'Company', 'mvrk-giveaway' ); ?></label>
				<input id="ga-company" name="company" type="text" tabindex="-1" autocomplete="off" />
			</div>

			<button type="submit" class="btn btn-primary mvrk-ga-submit"><?php esc_html_e( 'Enter the giveaway', 'mvrk-giveaway' ); ?> <?php mvrk_ga_icon( 'ticket' ); ?></button>
			<p class="mvrk-ga-fineprint"><?php esc_html_e( 'One entry per person per month. Void where prohibited. Winners drawn on video; see Winners page.', 'mvrk-giveaway' ); ?></p>
		</form>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render the email-entry card (matches the flyers: email proof of purchase).
 */
function mvrk_ga_render_email_entry() {
	wp_enqueue_style( 'mvrk-ga' );
	$email  = mvrk_ga_email();
	$mailto = mvrk_ga_mailto();
	$steps  = array(
		__( 'Buy MVRK from our shop or a stockist.', 'mvrk-giveaway' ),
		sprintf( /* translators: %s: email address */ __( 'Email your proof of purchase (a photo of your receipt) to %s.', 'mvrk-giveaway' ), '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' ),
		__( 'We verify it and add your name to this month\'s wheel.', 'mvrk-giveaway' ),
		__( 'The owner draws the winner on video — watch the Winners page.', 'mvrk-giveaway' ),
	);
	ob_start();
	?>
	<div class="mvrk-ga-email">
		<ol class="mvrk-ga-email-steps">
			<?php foreach ( $steps as $i => $step ) : ?>
				<li><span class="mvrk-ga-email-n"><?php echo (int) ( $i + 1 ); ?></span><span><?php echo wp_kses_post( $step ); ?></span></li>
			<?php endforeach; ?>
		</ol>
		<a href="<?php echo esc_url( $mailto ); ?>" class="btn btn-primary mvrk-ga-email-btn"><?php mvrk_ga_icon( 'mail' ); ?> <?php esc_html_e( 'Email your entry', 'mvrk-giveaway' ); ?></a>
		<p class="mvrk-ga-email-to"><?php printf( /* translators: %s: email link */ esc_html__( 'Or email us directly at %s', 'mvrk-giveaway' ), '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' ); ?></p>
		<p class="mvrk-ga-fineprint"><?php esc_html_e( 'A qualifying purchase and valid proof are required. One entry per person, per month. 21+ only. Void where prohibited. See Official Rules.', 'mvrk-giveaway' ); ?></p>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * The full [mvrk_giveaway] page.
 */
function mvrk_ga_giveaway_shortcode() {
	wp_enqueue_style( 'mvrk-ga' );
	wp_enqueue_script( 'mvrk-ga-wheel' );
	$ga_email = mvrk_ga_email();

	$month   = mvrk_ga_month();
	$count   = mvrk_ga_count( $month, 'approved' );
	$prize   = mvrk_ga_prize();
	$winner  = function_exists( 'mvrk_ga_latest_winner' ) ? mvrk_ga_latest_winner() : null;

	ob_start();
	?>
	<div class="mvrk-ga">
		<section class="mvrk-ga-hero">
			<div class="container-mvrk">
				<p class="eyebrow"><?php esc_html_e( 'Every month · free product · 21+', 'mvrk-giveaway' ); ?></p>
				<h1 class="mvrk-ga-hero__title"><?php esc_html_e( 'Win 100 Tablets — Every Month', 'mvrk-giveaway' ); ?></h1>
				<p class="mvrk-ga-hero__lead"><?php printf( /* translators: %s: email link */ wp_kses_post( __( 'Buy MVRK, then email your proof of purchase to %s for a chance to win 100 free tablets every month. Your name joins the wheel below — and the owner draws a winner on video for everyone to see.', 'mvrk-giveaway' ) ), '<a href="mailto:' . esc_attr( $ga_email ) . '">' . esc_html( $ga_email ) . '</a>' ); ?></p>
				<p class="mvrk-ga-prize"><strong><?php esc_html_e( 'This month\'s prize:', 'mvrk-giveaway' ); ?></strong> <?php echo esc_html( $prize ); ?></p>
			</div>
		</section>

		<section class="mvrk-ga-main container-mvrk">
			<div class="mvrk-ga-grid">
				<div class="mvrk-ga-wheel-col">
					<div class="mvrk-ga-wheel-head">
						<h2><?php echo esc_html( mvrk_ga_month_label( $month ) ); ?> <?php esc_html_e( 'entrants', 'mvrk-giveaway' ); ?></h2>
						<span class="mvrk-ga-pill"><?php echo esc_html( number_format_i18n( $count ) ); ?> <?php esc_html_e( 'on the wheel', 'mvrk-giveaway' ); ?></span>
					</div>
					<?php echo mvrk_ga_render_wheel(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<p class="mvrk-ga-wheel-note"><?php esc_html_e( 'The wheel shows everyone currently entered this month. The official winner is drawn by the owner on video — no automated pick.', 'mvrk-giveaway' ); ?></p>
				</div>

				<div class="mvrk-ga-form-col">
					<h2><?php esc_html_e( 'How to enter', 'mvrk-giveaway' ); ?></h2>
					<?php echo mvrk_ga_render_email_entry(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			</div>
		</section>

		<section class="mvrk-ga-how section-pad">
			<div class="container-mvrk">
				<h2 class="mvrk-ga-how__title"><?php esc_html_e( 'How it works', 'mvrk-giveaway' ); ?></h2>
				<ol class="mvrk-ga-steps">
					<li><span class="mvrk-ga-step__n">1</span><h3><?php esc_html_e( 'Buy &amp; email proof', 'mvrk-giveaway' ); ?></h3><p><?php printf( /* translators: %s: email */ esc_html__( 'Buy MVRK, then email your proof of purchase to %s. One entry per person, per month.', 'mvrk-giveaway' ), esc_html( mvrk_ga_email() ) ); ?></p></li>
					<li><span class="mvrk-ga-step__n">2</span><h3><?php esc_html_e( 'Get on the wheel', 'mvrk-giveaway' ); ?></h3><p><?php esc_html_e( 'We verify every entry. Once confirmed, your name appears on this month\'s wheel.', 'mvrk-giveaway' ); ?></p></li>
					<li><span class="mvrk-ga-step__n">3</span><h3><?php esc_html_e( 'Watch the draw', 'mvrk-giveaway' ); ?></h3><p><?php esc_html_e( 'At month\'s end the owner draws a winner on camera. The video is posted to the Winners page.', 'mvrk-giveaway' ); ?></p></li>
				</ol>
				<p class="mvrk-ga-legal-link"><a href="<?php echo esc_url( mvrk_ga_rules_url() ); ?>"><?php esc_html_e( 'Read the Official Rules & eligibility', 'mvrk-giveaway' ); ?></a></p>
			</div>
		</section>

		<?php if ( $winner ) : ?>
			<section class="mvrk-ga-latest section-pad">
				<div class="container-mvrk">
					<p class="eyebrow"><?php esc_html_e( 'Most recent winner', 'mvrk-giveaway' ); ?></p>
					<h2><?php echo esc_html( $winner['name'] ); ?> &mdash; <?php echo esc_html( $winner['month_label'] ); ?></h2>
					<a class="btn btn-secondary" href="<?php echo esc_url( home_url( '/winners/' ) ); ?>"><?php esc_html_e( 'Watch the draw & see all winners', 'mvrk-giveaway' ); ?></a>
				</div>
			</section>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'mvrk_giveaway', 'mvrk_ga_giveaway_shortcode' );
add_shortcode( 'mvrk_giveaway_form', function () { return mvrk_ga_render_form(); } );
