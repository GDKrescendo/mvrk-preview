<?php
/**
 * Giveaway helpers.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public display name: first name + last initial (privacy on the wheel).
 *
 * @param string $full Full name.
 */
function mvrk_ga_display_name( $full ) {
	$full  = trim( wp_strip_all_tags( $full ) );
	$parts = preg_split( '/\s+/', $full );
	if ( count( $parts ) < 2 ) {
		return $full;
	}
	$last = end( $parts );
	return $parts[0] . ' ' . strtoupper( substr( $last, 0, 1 ) ) . '.';
}

/**
 * The current giveaway month key.
 */
function mvrk_ga_month() {
	return gmdate( 'Y-m' );
}

/**
 * Human label for a YYYY-MM key.
 */
function mvrk_ga_month_label( $key ) {
	$ts = strtotime( $key . '-01' );
	return $ts ? gmdate( 'F Y', $ts ) : $key;
}

/**
 * Current monthly prize description (editable in the admin settings).
 */
function mvrk_ga_prize() {
	return get_option( 'mvrk_ga_prize', __( 'One free jar of MVRK (winner\'s choice of line & flavor)', 'mvrk-giveaway' ) );
}

/**
 * Official Rules URL.
 */
function mvrk_ga_rules_url() {
	return home_url( '/official-rules/' );
}

/**
 * The giveaway entry email (matches the flyers). Uses the theme config when
 * available, else the WP admin email.
 */
function mvrk_ga_email() {
	if ( function_exists( 'mvrk_get' ) ) {
		$email = mvrk_get( 'business.email' );
		if ( $email && is_email( $email ) ) {
			return $email;
		}
	}
	return apply_filters( 'mvrk_ga_email', 'info@mvrktabz.com' );
}

/**
 * A ready-to-use mailto link for entering the giveaway.
 */
function mvrk_ga_mailto() {
	$subject = rawurlencode( 'MVRK Monthly Giveaway Entry' );
	$body    = rawurlencode( "Hi MVRK team,\n\nI'd like to enter this month's giveaway. My proof of purchase is attached.\n\nName:\nEmail:\n\nThank you!" );
	return 'mailto:' . mvrk_ga_email() . '?subject=' . $subject . '&body=' . $body;
}

/**
 * Minimal inline icon (mirrors the theme's set so the plugin is theme-independent).
 */
function mvrk_ga_icon( $name ) {
	if ( function_exists( 'mvrk_icon' ) ) {
		mvrk_icon( $name );
		return;
	}
	$paths = array(
		'ticket'       => '<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/>',
		'upload'       => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5"/><path d="M12 3v12"/>',
		'check-circle' => '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
		'trophy'       => '<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/>',
	);
	$inner = isset( $paths[ $name ] ) ? $paths[ $name ] : '';
	printf( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" class="ico" aria-hidden="true">%s</svg>', $inner ); // phpcs:ignore WordPress.Security.EscapeOutput
}
