/* MVRK giveaway form — toggle between receipt (purchase) and free (AMOE) entry. */
(function () {
  "use strict";
  var form = document.querySelector(".mvrk-ga-form");
  if (!form) return;

  var typeInput = form.querySelector("#mvrk-ga-entry-type");
  var purchase = form.querySelector(".mvrk-ga-purchase-only");
  var amoe = form.querySelector(".mvrk-ga-amoe-only");
  var receipt = form.querySelector("#ga-receipt");
  var btns = form.querySelectorAll(".mvrk-ga-toggle__btn");

  function setMode(mode) {
    if (typeInput) typeInput.value = mode;
    var isPurchase = mode === "purchase";
    if (purchase) purchase.hidden = !isPurchase;
    if (amoe) amoe.hidden = isPurchase;
    if (receipt) receipt.required = isPurchase;
    btns.forEach(function (b) {
      var active = b.getAttribute("data-mode") === mode;
      b.classList.toggle("is-active", active);
      b.setAttribute("aria-selected", active ? "true" : "false");
    });
  }

  btns.forEach(function (b) {
    b.addEventListener("click", function () {
      setMode(b.getAttribute("data-mode"));
    });
  });

  setMode("purchase");
})();
