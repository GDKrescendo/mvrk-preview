<?php
/**
 * Giveaway data layer.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fully-qualified table name.
 */
function mvrk_ga_table() {
	global $wpdb;
	return $wpdb->prefix . MVRK_GA_TABLE;
}

/**
 * Create / upgrade the entries table.
 */
function mvrk_ga_create_table() {
	global $wpdb;
	$table           = mvrk_ga_table();
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE {$table} (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		name VARCHAR(120) NOT NULL,
		email VARCHAR(190) NOT NULL,
		phone VARCHAR(40) DEFAULT '',
		order_no VARCHAR(80) DEFAULT '',
		receipt_url TEXT DEFAULT '',
		entry_type VARCHAR(20) NOT NULL DEFAULT 'purchase',
		month VARCHAR(7) NOT NULL,
		status VARCHAR(20) NOT NULL DEFAULT 'pending',
		ip VARCHAR(64) DEFAULT '',
		created_at DATETIME NOT NULL,
		PRIMARY KEY (id),
		KEY month_status (month, status),
		KEY email_month (email, month)
	) {$charset_collate};";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
}

/**
 * Insert an entry. Returns insert id or WP_Error.
 *
 * @param array $data Sanitized entry data.
 */
function mvrk_ga_insert_entry( $data ) {
	global $wpdb;

	$defaults = array(
		'name'        => '',
		'email'       => '',
		'phone'       => '',
		'order_no'    => '',
		'receipt_url' => '',
		'entry_type'  => 'purchase',
		'month'       => gmdate( 'Y-m' ),
		'status'      => 'pending',
		'ip'          => '',
		'created_at'  => current_time( 'mysql', true ),
	);
	$data = wp_parse_args( $data, $defaults );

	$ok = $wpdb->insert( mvrk_ga_table(), $data ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	if ( false === $ok ) {
		return new WP_Error( 'mvrk_ga_db', __( 'Could not save your entry. Please try again.', 'mvrk-giveaway' ) );
	}
	return (int) $wpdb->insert_id;
}

/**
 * Has this email already entered this month?
 *
 * @param string $email Email.
 * @param string $month YYYY-MM.
 */
function mvrk_ga_already_entered( $email, $month ) {
	global $wpdb;
	$count = $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB
		'SELECT COUNT(*) FROM ' . mvrk_ga_table() . ' WHERE email = %s AND month = %s AND status != %s',
		$email,
		$month,
		'rejected'
	) );
	return (int) $count > 0;
}

/**
 * Get entries with optional filters.
 *
 * @param array $args month, status, limit, offset.
 */
function mvrk_ga_get_entries( $args = array() ) {
	global $wpdb;
	$args   = wp_parse_args( $args, array(
		'month'  => '',
		'status' => '',
		'limit'  => 200,
		'offset' => 0,
	) );
	$where  = array( '1=1' );
	$params = array();
	if ( $args['month'] ) {
		$where[]  = 'month = %s';
		$params[] = $args['month'];
	}
	if ( $args['status'] ) {
		$where[]  = 'status = %s';
		$params[] = $args['status'];
	}
	$sql      = 'SELECT * FROM ' . mvrk_ga_table() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY created_at DESC LIMIT %d OFFSET %d';
	$params[] = (int) $args['limit'];
	$params[] = (int) $args['offset'];

	return $wpdb->get_results( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB
}

/**
 * Count entries for a month/status.
 */
function mvrk_ga_count( $month = '', $status = '' ) {
	global $wpdb;
	$where  = array( '1=1' );
	$params = array();
	if ( $month ) {
		$where[]  = 'month = %s';
		$params[] = $month;
	}
	if ( $status ) {
		$where[]  = 'status = %s';
		$params[] = $status;
	}
	$sql = 'SELECT COUNT(*) FROM ' . mvrk_ga_table() . ' WHERE ' . implode( ' AND ', $where );
	if ( $params ) {
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB
	}
	return (int) $wpdb->get_var( $sql ); // phpcs:ignore WordPress.DB
}

/**
 * Approved first names for a month (for the wheel).
 *
 * @param string $month YYYY-MM.
 */
function mvrk_ga_approved_names( $month ) {
	global $wpdb;
	$rows = $wpdb->get_col( $wpdb->prepare( // phpcs:ignore WordPress.DB
		'SELECT name FROM ' . mvrk_ga_table() . ' WHERE month = %s AND status = %s ORDER BY created_at ASC',
		$month,
		'approved'
	) );
	// Use first name + last initial for privacy on the public wheel.
	return array_map( 'mvrk_ga_display_name', (array) $rows );
}

/**
 * Update an entry's status.
 */
function mvrk_ga_set_status( $id, $status ) {
	global $wpdb;
	$allowed = array( 'pending', 'approved', 'rejected' );
	if ( ! in_array( $status, $allowed, true ) ) {
		return false;
	}
	return $wpdb->update( mvrk_ga_table(), array( 'status' => $status ), array( 'id' => (int) $id ) ); // phpcs:ignore WordPress.DB
}

/**
 * Fetch a single entry.
 */
function mvrk_ga_get_entry( $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . mvrk_ga_table() . ' WHERE id = %d', (int) $id ) ); // phpcs:ignore WordPress.DB
}
