<?php
/**
 * The name wheel — markup + REST endpoint feeding it.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the REST route returning this month's approved entrant display-names.
 */
function mvrk_ga_register_rest() {
	register_rest_route( 'mvrk/v1', '/entrants', array(
		'methods'             => WP_REST_Server::READABLE,
		'permission_callback' => '__return_true',
		'args'                => array(
			'month' => array(
				'sanitize_callback' => 'sanitize_text_field',
			),
		),
		'callback'            => 'mvrk_ga_rest_entrants',
	) );
}
add_action( 'rest_api_init', 'mvrk_ga_register_rest' );

/**
 * REST callback.
 *
 * @param WP_REST_Request $req Request.
 */
function mvrk_ga_rest_entrants( $req ) {
	$month = $req->get_param( 'month' );
	if ( ! $month || ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
		$month = mvrk_ga_month();
	}
	$names = mvrk_ga_approved_names( $month );
	return rest_ensure_response( array(
		'month' => $month,
		'count' => count( $names ),
		'names' => array_values( $names ),
	) );
}

/**
 * Render the wheel container. JS (wheel.js) draws it on a canvas.
 */
function mvrk_ga_render_wheel() {
	ob_start();
	?>
	<div class="mvrk-wheel" data-mvrk-wheel>
		<div class="mvrk-wheel__stage">
			<div class="mvrk-wheel__pointer" aria-hidden="true"></div>
			<canvas class="mvrk-wheel__canvas" width="520" height="520" role="img" aria-label="<?php esc_attr_e( 'Wheel of this month\'s giveaway entrants', 'mvrk-giveaway' ); ?>"></canvas>
			<div class="mvrk-wheel__hub" aria-hidden="true"></div>
		</div>
		<div class="mvrk-wheel__empty" hidden><?php esc_html_e( 'No approved entries yet this month — be the first on the wheel.', 'mvrk-giveaway' ); ?></div>
		<button type="button" class="btn btn-secondary mvrk-wheel__spin" data-mvrk-spin><?php esc_html_e( 'Spin the wheel', 'mvrk-giveaway' ); ?></button>
		<p class="mvrk-wheel__result" data-mvrk-result aria-live="polite"></p>
	</div>
	<?php
	return ob_get_clean();
}
