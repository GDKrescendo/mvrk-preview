<?php
/**
 * Winners — CPT, meta box (month / winner / video), archive shortcode.
 *
 * @package MVRK_Giveaway
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Winners custom post type.
 */
function mvrk_ga_register_winner_cpt() {
	register_post_type( 'mvrk_winner', array(
		'labels'       => array(
			'name'          => __( 'Winners', 'mvrk-giveaway' ),
			'singular_name' => __( 'Winner', 'mvrk-giveaway' ),
			'add_new_item'  => __( 'Add Monthly Winner', 'mvrk-giveaway' ),
			'edit_item'     => __( 'Edit Winner', 'mvrk-giveaway' ),
			'menu_name'     => __( 'Giveaway Winners', 'mvrk-giveaway' ),
		),
		'public'       => true,
		'show_in_menu' => 'mvrk-giveaway',
		'has_archive'  => false,
		'rewrite'      => array( 'slug' => 'winner' ),
		'supports'     => array( 'title' ),
		'menu_icon'    => 'dashicons-awards',
	) );
}

/**
 * Winner meta box.
 */
function mvrk_ga_winner_metabox() {
	add_meta_box( 'mvrk_winner_meta', __( 'Winner details', 'mvrk-giveaway' ), 'mvrk_ga_winner_metabox_html', 'mvrk_winner', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'mvrk_ga_winner_metabox' );

/**
 * Render the meta box.
 *
 * @param WP_Post $post Post.
 */
function mvrk_ga_winner_metabox_html( $post ) {
	wp_nonce_field( 'mvrk_winner_save', 'mvrk_winner_nonce' );
	$month  = get_post_meta( $post->ID, '_mvrk_month', true );
	$name   = get_post_meta( $post->ID, '_mvrk_winner_name', true );
	$prize  = get_post_meta( $post->ID, '_mvrk_prize', true );
	$video  = get_post_meta( $post->ID, '_mvrk_video_url', true );
	if ( ! $month ) {
		$month = gmdate( 'Y-m' );
	}
	?>
	<p style="margin:.6em 0"><label><strong><?php esc_html_e( 'Month (YYYY-MM)', 'mvrk-giveaway' ); ?></strong><br>
		<input type="text" name="mvrk_month" value="<?php echo esc_attr( $month ); ?>" placeholder="2026-06" pattern="\d{4}-\d{2}" class="regular-text" /></label></p>
	<p style="margin:.6em 0"><label><strong><?php esc_html_e( 'Winner name (shown publicly)', 'mvrk-giveaway' ); ?></strong><br>
		<input type="text" name="mvrk_winner_name" value="<?php echo esc_attr( $name ); ?>" class="regular-text" /></label></p>
	<p style="margin:.6em 0"><label><strong><?php esc_html_e( 'Prize awarded', 'mvrk-giveaway' ); ?></strong><br>
		<input type="text" name="mvrk_prize" value="<?php echo esc_attr( $prize ); ?>" class="regular-text" placeholder="<?php echo esc_attr( mvrk_ga_prize() ); ?>" /></label></p>
	<p style="margin:.6em 0"><label><strong><?php esc_html_e( 'Draw video URL', 'mvrk-giveaway' ); ?></strong><br>
		<input type="url" name="mvrk_video_url" value="<?php echo esc_url( $video ); ?>" class="large-text" placeholder="https://www.youtube.com/watch?v=… (unlisted recommended)" /></label></p>
	<p class="description"><?php esc_html_e( 'Paste an (unlisted) YouTube or Vimeo link of the monthly draw, or upload an MP4 to the Media Library and paste its file URL. This is the official winner reveal.', 'mvrk-giveaway' ); ?></p>
	<?php
}

/**
 * Save winner meta.
 *
 * @param int $post_id Post ID.
 */
function mvrk_ga_winner_save( $post_id ) {
	if ( ! isset( $_POST['mvrk_winner_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['mvrk_winner_nonce'] ), 'mvrk_winner_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$fields = array(
		'_mvrk_month'       => isset( $_POST['mvrk_month'] ) ? sanitize_text_field( wp_unslash( $_POST['mvrk_month'] ) ) : '',
		'_mvrk_winner_name' => isset( $_POST['mvrk_winner_name'] ) ? sanitize_text_field( wp_unslash( $_POST['mvrk_winner_name'] ) ) : '',
		'_mvrk_prize'       => isset( $_POST['mvrk_prize'] ) ? sanitize_text_field( wp_unslash( $_POST['mvrk_prize'] ) ) : '',
		'_mvrk_video_url'   => isset( $_POST['mvrk_video_url'] ) ? esc_url_raw( wp_unslash( $_POST['mvrk_video_url'] ) ) : '',
	);
	foreach ( $fields as $key => $val ) {
		update_post_meta( $post_id, $key, $val );
	}
}
add_action( 'save_post_mvrk_winner', 'mvrk_ga_winner_save' );

/**
 * Most recent winner as an array, or null.
 */
function mvrk_ga_latest_winner() {
	$q = new WP_Query( array(
		'post_type'      => 'mvrk_winner',
		'posts_per_page' => 1,
		'meta_key'       => '_mvrk_month',
		'orderby'        => 'meta_value',
		'order'          => 'DESC',
		'no_found_rows'  => true,
	) );
	if ( ! $q->have_posts() ) {
		return null;
	}
	$p     = $q->posts[0];
	$month = get_post_meta( $p->ID, '_mvrk_month', true );
	return array(
		'name'        => get_post_meta( $p->ID, '_mvrk_winner_name', true ),
		'month'       => $month,
		'month_label' => mvrk_ga_month_label( $month ),
		'prize'       => get_post_meta( $p->ID, '_mvrk_prize', true ),
		'video'       => get_post_meta( $p->ID, '_mvrk_video_url', true ),
	);
}

/**
 * Turn a video URL into an embed/player.
 *
 * @param string $url Video URL.
 */
function mvrk_ga_video_embed( $url ) {
	if ( ! $url ) {
		return '';
	}
	// YouTube.
	if ( preg_match( '~(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([A-Za-z0-9_-]{6,})~', $url, $m ) ) {
		return '<div class="mvrk-video"><iframe src="https://www.youtube-nocookie.com/embed/' . esc_attr( $m[1] ) . '" title="Winner draw video" loading="lazy" allow="encrypted-media; picture-in-picture" allowfullscreen></iframe></div>';
	}
	// Vimeo.
	if ( preg_match( '~vimeo\.com/(?:video/)?(\d+)~', $url, $m ) ) {
		return '<div class="mvrk-video"><iframe src="https://player.vimeo.com/video/' . esc_attr( $m[1] ) . '" title="Winner draw video" loading="lazy" allow="fullscreen; picture-in-picture" allowfullscreen></iframe></div>';
	}
	// Direct file.
	if ( preg_match( '~\.(mp4|webm|mov)(\?.*)?$~i', $url ) ) {
		return '<div class="mvrk-video"><video controls preload="metadata" playsinline src="' . esc_url( $url ) . '"></video></div>';
	}
	return '<p><a class="btn btn-secondary" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Watch the draw', 'mvrk-giveaway' ) . '</a></p>';
}

/**
 * [mvrk_winners] — the winners archive.
 */
function mvrk_ga_winners_shortcode() {
	wp_enqueue_style( 'mvrk-ga' );

	$q = new WP_Query( array(
		'post_type'      => 'mvrk_winner',
		'posts_per_page' => 36,
		'meta_key'       => '_mvrk_month',
		'orderby'        => 'meta_value',
		'order'          => 'DESC',
	) );

	ob_start();
	?>
	<div class="mvrk-ga">
		<section class="mvrk-ga-hero">
			<div class="container-mvrk">
				<p class="eyebrow"><?php esc_html_e( 'Monthly draws on video', 'mvrk-giveaway' ); ?></p>
				<h1 class="mvrk-ga-hero__title"><?php esc_html_e( 'Winners', 'mvrk-giveaway' ); ?></h1>
				<p class="mvrk-ga-hero__lead"><?php esc_html_e( 'Every month, the owner draws the winner on camera — no automated pick, nothing hidden. Here\'s every draw.', 'mvrk-giveaway' ); ?></p>
				<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/giveaway/' ) ); ?>"><?php esc_html_e( 'Enter this month', 'mvrk-giveaway' ); ?></a>
			</div>
		</section>

		<section class="container-mvrk section-pad">
			<?php if ( $q->have_posts() ) : ?>
				<div class="mvrk-winners-grid">
					<?php
					while ( $q->have_posts() ) :
						$q->the_post();
						$id    = get_the_ID();
						$month = get_post_meta( $id, '_mvrk_month', true );
						$name  = get_post_meta( $id, '_mvrk_winner_name', true );
						$prize = get_post_meta( $id, '_mvrk_prize', true );
						$video = get_post_meta( $id, '_mvrk_video_url', true );
						?>
						<article class="mvrk-winner card">
							<?php echo mvrk_ga_video_embed( $video ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<div class="mvrk-winner__body">
								<p class="mvrk-winner__month"><?php echo esc_html( mvrk_ga_month_label( $month ) ); ?></p>
								<h2 class="mvrk-winner__name"><?php echo esc_html( $name ? $name : get_the_title() ); ?></h2>
								<?php if ( $prize ) : ?>
									<p class="mvrk-winner__prize"><?php mvrk_ga_icon( 'trophy' ); ?> <?php echo esc_html( $prize ); ?></p>
								<?php endif; ?>
							</div>
						</article>
					<?php endwhile; ?>
				</div>
			<?php else : ?>
				<div class="mvrk-ga-empty card">
					<?php mvrk_ga_icon( 'trophy' ); ?>
					<h2><?php esc_html_e( 'The first draw is coming.', 'mvrk-giveaway' ); ?></h2>
					<p><?php esc_html_e( 'No winners posted yet. Enter this month for your shot — the first monthly draw video will land right here.', 'mvrk-giveaway' ); ?></p>
					<a class="btn btn-primary" href="<?php echo esc_url( home_url( '/giveaway/' ) ); ?>"><?php esc_html_e( 'Enter the giveaway', 'mvrk-giveaway' ); ?></a>
				</div>
			<?php endif; ?>
		</section>
	</div>
	<?php
	wp_reset_postdata();
	return ob_get_clean();
}
add_shortcode( 'mvrk_winners', 'mvrk_ga_winners_shortcode' );
